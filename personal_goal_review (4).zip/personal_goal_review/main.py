#!/usr/bin/env python3
"""Personal Goal Review - launcher.

    python main.py            terminal (menu-driven) interface
    python main.py --gui      graphical (Tkinter) interface
    python main.py --seed     load the 40-goal sample dataset first
"""

import argparse
import sys
from pathlib import Path

from goal_review.logic import GoalManager
from goal_review.storage import Storage
from goal_review import seed

BASE_DIR = Path(__file__).resolve().parent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Personal Goal Review - track goals, milestones, "
                                                 "completion % and reflections.")
    parser.add_argument("--gui", action="store_true", help="open the Tkinter graphical interface")
    parser.add_argument("--cli", action="store_true", help="open the terminal interface (default)")
    parser.add_argument("--seed", action="store_true", help="add the 40-goal sample dataset if the data file is empty")
    parser.add_argument("--data-dir", default=str(BASE_DIR / "data"), help="folder holding goals.json")
    parser.add_argument("--export-dir", default=str(BASE_DIR / "exports"), help="folder for exported reports")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    data_dir = Path(args.data_dir)
    manager = GoalManager(Storage(data_dir / "goals.json"))
    if args.seed and not manager.goals:
        manager.add_many(seed.generate_sample_goals(manager.today))
    seed.write_legacy_sample(data_dir) if not (data_dir / "legacy_import_sample.csv").exists() else None

    if args.gui and not args.cli:
        try:
            from goal_review.gui import launch_gui
        except ImportError:
            print("Tkinter is not available in this Python installation.\n"
                  "Linux: sudo apt install python3-tk | Windows/macOS: reinstall Python with Tcl/Tk.\n"
                  "Starting the terminal interface instead.\n")
        else:
            launch_gui(manager, args.export_dir, data_dir)
            return 0
    from goal_review.cli import run_cli
    run_cli(manager, args.export_dir, data_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
