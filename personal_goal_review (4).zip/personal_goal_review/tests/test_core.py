"""Unit tests - run from the project folder with:

    python -m unittest discover -s tests -v
"""
import csv
import json
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from goal_review import importer, reports, seed
from goal_review.logic import GoalManager, GoalManagerError, GoalNotFound
from goal_review.storage import Storage
from goal_review.validation import (ValidationError, validate_category, validate_date, validate_date_order,
                                    validate_milestone_title, validate_note, validate_priority,
                                    validate_progress, validate_title)

TODAY = date(2026, 11, 25)


def make_manager(tmp):
    return GoalManager(Storage(Path(tmp) / "goals.json"), today=TODAY)


class ValidationTests(unittest.TestCase):
    def test_title(self):
        self.assertEqual(validate_title("  Learn   Python  "), "Learn Python")
        for bad in ("", "ab", "x" * 81, "!!!", None):
            with self.assertRaises(ValidationError):
                validate_title(bad)
        self.assertEqual(len(validate_title("x" * 80)), 80)

    def test_progress_boundaries(self):
        for good, expected in ((0, 0), (100, 100), ("55", 55), ("75%", 75), (" 10 ", 10), (40.0, 40)):
            self.assertEqual(validate_progress(good), expected)
        for bad in (-1, 101, "abc", "", "5.5", 5.5, True, "1e2", None):
            with self.assertRaises(ValidationError):
                validate_progress(bad)

    def test_dates(self):
        self.assertEqual(validate_date("2026-12-31"), "2026-12-31")
        self.assertEqual(validate_date("31/12/2026"), "2026-12-31")
        self.assertEqual(validate_date("31-12-2026"), "2026-12-31")
        for bad in ("", "2026-13-01", "2026-02-30", "tomorrow", "1999-01-01", "2101-01-01"):
            with self.assertRaises(ValidationError):
                validate_date(bad)
        self.assertEqual(validate_date("", allow_blank=True), "")
        with self.assertRaises(ValidationError):
            validate_date_order("2026-12-01", "2026-11-01")

    def test_priority_category_misc(self):
        self.assertEqual(validate_priority("h"), "High")
        self.assertEqual(validate_priority("2"), "Medium")
        with self.assertRaises(ValidationError):
            validate_priority("urgent")
        self.assertEqual(validate_category("career"), "Career")
        for bad in ("", "1abc", "a", "bad;cat", "x" * 31):
            with self.assertRaises(ValidationError):
                validate_category(bad)
        self.assertEqual(validate_milestone_title("[x] Do; thing"), "Do, thing")
        self.assertEqual(validate_note("a | b"), "a / b")
        with self.assertRaises(ValidationError):
            validate_note("   ")


class LogicTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.m = make_manager(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def add(self, title="Finish thesis", **kw):
        args = dict(category="Academics", priority="High", start_date="2026-11-01", deadline="2026-12-31")
        args.update(kw)
        return self.m.add_goal(title, **args)

    def test_add_and_persist(self):
        g = self.add(milestones=["Outline", "Draft", "Final"])
        self.assertEqual(g.id, 1)
        self.assertEqual(g.completion, 0)
        reloaded = make_manager(self.tmp.name)
        self.assertEqual(len(reloaded.goals), 1)
        self.assertEqual(reloaded.goals[0].title, "Finish thesis")

    def test_completion_from_milestones(self):
        g = self.add(milestones=["A1", "B2", "C3", "D4"])
        self.m.toggle_milestone(g.id, 0)
        self.assertEqual(g.completion, 25.0)
        self.m.toggle_milestone(g.id, 1)
        self.m.toggle_milestone(g.id, 2)
        self.assertEqual(g.completion, 75.0)
        self.m.toggle_milestone(g.id, 3)
        self.assertEqual(g.status(TODAY), "Completed")
        self.assertEqual(g.completed_on, "2026-11-25")
        self.m.toggle_milestone(g.id, 3)
        self.assertIsNone(g.completed_on)
        with self.assertRaises(GoalManagerError):
            self.m.set_progress(g.id, 50)           # milestone-driven goals reject manual progress
        with self.assertRaises(GoalManagerError):
            self.m.toggle_milestone(g.id, 9)

    def test_manual_progress_and_status(self):
        g = self.add(progress=0)
        self.assertEqual(g.status(TODAY), "Not Started")
        self.m.set_progress(g.id, 40)
        self.assertEqual(g.status(TODAY), "In Progress")
        self.m.update_goal(g.id, deadline="2026-11-20")
        self.assertEqual(g.status(TODAY), "Overdue")
        self.m.set_progress(g.id, 100)
        self.assertEqual(g.status(TODAY), "Completed")

    def test_invalid_input_is_rejected_atomically(self):
        g = self.add()
        with self.assertRaises(ValidationError):
            self.m.update_goal(g.id, title="Valid new title", deadline="2026-10-01")   # before start
        self.assertEqual(g.title, "Finish thesis")        # nothing half-applied
        with self.assertRaises(ValidationError):
            self.add("ab")
        with self.assertRaises(GoalNotFound):
            self.m.get(99)

    def test_reflections_and_delete(self):
        g = self.add()
        self.m.add_reflection(g.id, "Went well | really")
        self.assertEqual(g.reflections[0].note, "Went well / really")
        self.m.delete_goal(g.id)
        self.assertEqual(self.m.goals, [])

    def test_search(self):
        a = self.add("Learn Django basics", category="Career", priority="Low", milestones=["Install Django"])
        b = self.add("Run a 5K", category="Fitness", priority="High")
        self.m.add_reflection(b.id, "Shin pain on long runs")
        self.assertEqual([g.id for g in self.m.search("django")], [a.id])
        self.assertEqual([g.id for g in self.m.search("shin")], [b.id])
        self.assertEqual([g.id for g in self.m.search(category="fitness")], [b.id])
        self.assertEqual([g.id for g in self.m.search(priority="low")], [a.id])
        self.assertEqual(len(self.m.search("learn django install")), 1)    # AND of words
        self.assertEqual(self.m.search("nothing-matches"), [])
        self.assertEqual([g.id for g in self.m.search(status="not started")], [a.id, b.id])

    def test_summary_and_warnings(self):
        self.m.add_many(seed.generate_sample_goals(TODAY))
        s = self.m.summary()
        self.assertEqual(s["total"], 40)
        self.assertEqual(sum(s["by_status"].values()), 40)
        self.assertTrue(0 <= s["avg_completion"] <= 100)
        self.assertEqual(sum(d["count"] for d in s["by_category"].values()), 40)
        kinds = {w.kind for w in self.m.warnings()}
        self.assertTrue({"overdue", "due-soon", "limit", "anomaly"} <= kinds)

    def test_empty_summary(self):
        s = self.m.summary()
        self.assertEqual((s["total"], s["avg_completion"], s["health"]), (0, 0.0, "No data"))
        self.assertEqual(self.m.warnings(), [])

    def test_anomaly_deadline_before_start_loads_and_warns(self):
        path = Path(self.tmp.name) / "goals.json"
        path.write_text(json.dumps({"goals": [{
            "id": 1, "title": "Backwards goal", "category": "Test", "priority": "Low",
            "start_date": "2026-12-01", "deadline": "2026-11-30"}]}), encoding="utf-8")
        m = make_manager(self.tmp.name)
        self.assertEqual(len(m.goals), 1)
        self.assertTrue(any(w.kind == "anomaly" for w in m.warnings()))


class StorageTests(unittest.TestCase):
    def test_missing_file_creates_template(self):
        with tempfile.TemporaryDirectory() as tmp:
            m = make_manager(tmp)
            self.assertEqual(m.goals, [])
            self.assertTrue((Path(tmp) / "goals.json").exists())

    def test_corrupt_file_is_backed_up(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "goals.json").write_text("{ this is not json", encoding="utf-8")
            m = make_manager(tmp)
            self.assertEqual(m.goals, [])
            self.assertTrue(any("Backed it up" in msg for msg in m.load_messages))
            self.assertEqual(len(list(Path(tmp).glob("goals.corrupt-*.json"))), 1)
            json.loads((Path(tmp) / "goals.json").read_text())   # fresh file is valid again

    def test_wrong_structure_and_bad_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "goals.json"
            p.write_text('{"hello": 1}', encoding="utf-8")
            self.assertEqual(make_manager(tmp).goals, [])
            good = {"id": 1, "title": "Good goal", "category": "Test", "priority": "Low", "deadline": "2026-12-31"}
            bad = {"id": 2, "title": "x", "category": "Test", "priority": "Low", "deadline": "2026-12-31"}
            dup = dict(good)
            p.write_text(json.dumps({"goals": [good, bad, dup, "junk", {"id": 5}]}), encoding="utf-8")
            m = make_manager(tmp)
            self.assertEqual([g.id for g in m.goals], [1])
            self.assertEqual(len(m.load_messages), 4)

    def test_empty_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "goals.json").write_text("", encoding="utf-8")
            self.assertEqual(make_manager(tmp).goals, [])

    def test_special_characters_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            m = make_manager(tmp)
            title = 'Trip to Goa, Kerala & "Hampi" \u2014 r\u00e9sum\u00e9'
            m.add_goal(title, "Personal", "Low", "2026-11-01", "2026-12-31")
            self.assertEqual(make_manager(tmp).goals[0].title, title)


class ImportExportTests(unittest.TestCase):
    def test_legacy_import_reports_every_bad_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            m = make_manager(tmp)
            legacy = seed.write_legacy_sample(tmp)
            result = importer.import_csv(m, legacy, tmp)
            self.assertTrue(result.ok)
            self.assertEqual(result.imported, 6)
            self.assertEqual(result.skipped, 8)
            self.assertEqual(len(m.goals), 6)
            self.assertTrue(Path(result.log_path).exists())
            self.assertIn("Line 7", Path(result.log_path).read_text())
            # importing the same file again: everything good is now a duplicate
            again = importer.import_csv(m, legacy, tmp)
            self.assertEqual(again.imported, 0)
            self.assertEqual(len(m.goals), 6)

    def test_import_failures(self):
        with tempfile.TemporaryDirectory() as tmp:
            m = make_manager(tmp)
            self.assertFalse(importer.import_csv(m, Path(tmp) / "nope.csv").ok)
            empty = Path(tmp) / "e.csv"
            empty.write_text("", encoding="utf-8")
            self.assertFalse(importer.import_csv(m, empty).ok)
            nohdr = Path(tmp) / "h.csv"
            nohdr.write_text("a,b\n1,2\n", encoding="utf-8")
            self.assertIn("Missing required", importer.import_csv(m, nohdr).fatal)

    def test_export_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            m = make_manager(tmp)
            m.add_many(seed.generate_sample_goals(TODAY))
            paths = reports.export_all(m, Path(tmp) / "out")
            self.assertEqual({p.suffix for p in paths}, {".md", ".txt", ".csv"})
            for p in paths:
                self.assertGreater(p.stat().st_size, 100)
            goals_csv = [p for p in paths if p.name.startswith("goals_report")][0]
            with open(goals_csv, newline="", encoding="utf-8") as fh:
                self.assertEqual(len(list(csv.DictReader(fh))), 40)
            # re-import the exported CSV into a fresh store: all 40 survive
            with tempfile.TemporaryDirectory() as tmp2:
                m2 = make_manager(tmp2)
                result = importer.import_csv(m2, goals_csv)
                self.assertEqual((result.imported, result.skipped), (40, 0))
                self.assertEqual([round(g.completion) for g in m2.goals], [round(g.completion) for g in m.goals])


class SeedTests(unittest.TestCase):
    def test_sample_dataset_is_valid_and_varied(self):
        goals = seed.generate_sample_goals(TODAY)
        self.assertEqual(len(goals), 40)
        self.assertEqual(len({g.id for g in goals}), 40)
        self.assertGreaterEqual(len({g.category for g in goals}), 6)
        self.assertTrue(any(g.completion == 0 for g in goals))
        self.assertTrue(any(g.completion == 100 for g in goals))
        self.assertTrue(any(len(g.title) == 80 for g in goals))

    def test_sample_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            paths = seed.write_sample_files(tmp, TODAY)
            self.assertEqual(len(json.loads(paths[0].read_text())["goals"]), 40)


if __name__ == "__main__":
    unittest.main()
