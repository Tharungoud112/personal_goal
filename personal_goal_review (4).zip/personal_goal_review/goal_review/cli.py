"""Interactive, menu-driven terminal interface with ANSI colours and defensive input."""

from __future__ import annotations

import os
import sys
from datetime import timedelta
from pathlib import Path
from typing import Callable, List, Optional

from . import charts, importer, reports, seed
from .logic import GoalManager, GoalManagerError, GoalNotFound
from .models import (
    Goal,
    STATUS_COMPLETED,
    STATUS_IN_PROGRESS,
    STATUS_NOT_STARTED,
    STATUS_OVERDUE,
)
from .validation import (
    DATE_FMT,
    ValidationError,
    validate_category,
    validate_date,
    validate_date_order,
    validate_description,
    validate_int_range,
    validate_keyword,
    validate_milestone_title,
    validate_note,
    validate_priority,
    validate_priority_filter,
    validate_progress,
    validate_status_filter,
    validate_title,
)

APP_NAME = "Personal Goal Review"
PAGE_SIZE = 10
CANCEL_WORD = ":q"

# ----------------------------------------------------------------------------- styling
if os.name == "nt":                                     # enable ANSI escapes on Windows 10+
    os.system("")
USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
_CODES = {"bold": "1", "dim": "2", "red": "31", "green": "32", "yellow": "33",
          "blue": "34", "magenta": "35", "cyan": "36"}


def paint(text: str, *styles: str) -> str:
    if not USE_COLOR or not styles:
        return text
    return "\033[" + ";".join(_CODES[s] for s in styles) + "m" + text + "\033[0m"


_STATUS_STYLE = {
    STATUS_COMPLETED: ("green",), STATUS_OVERDUE: ("red", "bold"),
    STATUS_IN_PROGRESS: ("yellow",), STATUS_NOT_STARTED: ("dim",),
}
_LEVEL_STYLE = {"CRITICAL": ("red", "bold"), "WARNING": ("yellow", "bold"), "INFO": ("cyan",)}

BANNER = r"""
  ____                                   _    ____             _
 |  _ \ ___ _ __ ___  ___  _ __   __ _| |  / ___| ___   __ _| |
 | |_) / _ \ '__/ __|/ _ \| '_ \ / _` | | | |  _ / _ \ / _` | |
 |  __/  __/ |  \__ \ (_) | | | | (_| | | | |_| | (_) | (_| | |
 |_|   \___|_|  |___/\___/|_| |_|\__,_|_|  \____|\___/ \__,_|_|
                     ____            _
                    |  _ \ _____   _(_) _____      __
                    | |_) / _ \ \ / / |/ _ \ \ /\ / /
                    |  _ <  __/\ V /| |  __/\ V  V /
                    |_| \_\___| \_/ |_|\___| \_/\_/
"""


class Cancelled(Exception):
    """User typed ':q' (or input ended) while answering a prompt."""


# ----------------------------------------------------------------------------- output helpers
def heading(text: str) -> None:
    print()
    print(paint(f"== {text} ", "bold", "cyan") + paint("=" * max(4, 70 - len(text)), "cyan"))


def ok(text: str) -> None:
    print(paint("  \u2714 " + text, "green"))


def err(text: str) -> None:
    print(paint("  \u2716 " + text, "red"))


def note(text: str) -> None:
    print(paint("  " + text, "dim"))


def progress_bar(pct: float, width: int = 20) -> str:
    filled = int(round(width * max(0.0, min(100.0, pct)) / 100))
    colour = "green" if pct >= 100 else "yellow" if pct >= 40 else "red"
    return paint("\u2588" * filled, colour) + paint("\u2591" * (width - filled), "dim")


def trunc(text: str, width: int) -> str:
    return text if len(text) <= width else text[: width - 1] + "\u2026"


# ----------------------------------------------------------------------------- input helpers
def ask(label: str, validator: Optional[Callable] = None, default=None, allow_blank: bool = False,
        hint: Optional[str] = None):
    """Prompt until the validator accepts the answer.  ':q' cancels the whole action."""
    suffix = f" [{default}]" if default not in (None, "") else (" (optional)" if allow_blank else "")
    while True:
        try:
            raw = input(f"  {label}{suffix}: ").strip()
        except EOFError:
            raise Cancelled()
        if raw.lower() == CANCEL_WORD:
            raise Cancelled()
        if raw == "" and default is not None:
            raw = str(default)
        if raw == "" and allow_blank:
            return ""
        try:
            return validator(raw) if validator else raw
        except ValidationError as exc:
            err(str(exc))
            if hint:
                note(hint)


def ask_yes_no(label: str, default: bool = False) -> bool:
    def parse(raw: str) -> bool:
        value = raw.strip().lower()
        if value in ("y", "yes"):
            return True
        if value in ("n", "no"):
            return False
        raise ValidationError("Please answer y or n.")
    return ask(f"{label} (y/n)", parse, default="y" if default else "n")


def ask_goal(manager: GoalManager, label: str = "Goal ID") -> Goal:
    def parse(raw: str) -> Goal:
        goal_id = validate_int_range(raw, 1, 10**9, "Goal ID")
        try:
            return manager.get(goal_id)
        except GoalNotFound as exc:
            raise ValidationError(str(exc))
    return ask(label, parse)


def pause() -> None:
    try:
        input(paint("\n  Press Enter to continue...", "dim"))
    except EOFError:
        pass


# ----------------------------------------------------------------------------- tables
_COLUMNS = [("ID", 3, ">"), ("Title", 22, "<"), ("Category", 10, "<"), ("Pri", 4, "<"),
            ("Due", 10, "<"), ("Done", 5, ">"), ("Status", 11, "<")]


def _row_text(goal: Goal, today) -> List[str]:
    return [str(goal.id), goal.title, goal.category, goal.priority[:4], goal.deadline,
            f"{goal.completion:.0f}%", goal.status(today)]


def print_goal_table(goals: List[Goal], today, paginate: bool = True) -> None:
    if not goals:
        note("No goals to show.")
        return
    header = "  ".join(f"{name:{align}{width}}" for name, width, align in _COLUMNS)
    pages = [goals[i:i + PAGE_SIZE] for i in range(0, len(goals), PAGE_SIZE)] if paginate else [goals]
    page = 0
    while True:
        print()
        print("  " + paint(header, "bold"))
        print("  " + "\u2500" * len(header))
        for goal in pages[page]:
            cells = _row_text(goal, today)
            parts = []
            for (name, width, align), cell in zip(_COLUMNS, cells):
                text = f"{trunc(cell, width):{align}{width}}"
                if name == "Status":
                    text = paint(text, *_STATUS_STYLE[cell])
                parts.append(text)
            print("  " + "  ".join(parts))
        print("  " + "\u2500" * len(header))
        print(paint(f"  {len(goals)} goal(s) | page {page + 1}/{len(pages)}", "dim"))
        if len(pages) == 1:
            return
        try:
            choice = input(paint("  [N]ext  [P]revious  [Q]uit listing: ", "dim")).strip().lower()
        except EOFError:
            return
        if choice in ("n", "next", ""):
            page = min(page + 1, len(pages) - 1)
        elif choice in ("p", "prev", "previous"):
            page = max(page - 1, 0)
        elif choice in ("q", "quit"):
            return
        else:
            err("Enter N, P or Q.")


def print_goal_detail(goal: Goal, today) -> None:
    status = goal.status(today)
    heading(f"Goal #{goal.id}: {goal.title}")
    left = goal.days_left(today)
    due = f"{abs(left)} day(s) overdue" if left < 0 and status != STATUS_COMPLETED else (
        "done" if status == STATUS_COMPLETED else ("due today" if left == 0 else f"{left} day(s) left"))
    print(f"  Category    : {goal.category}")
    print(f"  Priority    : {goal.priority}")
    print(f"  Status      : {paint(status, *_STATUS_STYLE[status])}")
    print(f"  Start / Due : {goal.start_date}  ->  {goal.deadline}  ({due})")
    print(f"  Completion  : {progress_bar(goal.completion)} {goal.completion:.0f}%"
          + ("" if goal.milestones else paint("  (manual progress)", "dim")))
    if goal.completed_on:
        print(f"  Completed on: {goal.completed_on}")
    if goal.description:
        print(f"  Description : {goal.description}")
    print(f"  Milestones  : {goal.done_milestones}/{goal.total_milestones}")
    for i, m in enumerate(goal.milestones, start=1):
        box = paint("[x]", "green") if m.done else "[ ]"
        print(f"     {i:>2}. {box} {m.title}")
    print(f"  Reflections : {len(goal.reflections)}")
    for r in goal.reflections:
        print(f"     {paint(r.date, 'dim')}  {r.note}")


# ----------------------------------------------------------------------------- actions
class App:
    def __init__(self, manager: GoalManager, export_dir, data_dir):
        self.m = manager
        self.export_dir = Path(export_dir)
        self.data_dir = Path(data_dir)

    # ---- menu -------------------------------------------------------------
    def run(self) -> None:
        self.welcome()
        actions = {
            "1": ("Add a new goal", self.add_goal),
            "2": ("View all goals", self.list_goals),
            "3": ("View goal details", self.view_goal),
            "4": ("Edit goal / update progress", self.edit_goal),
            "5": ("Manage milestones", self.manage_milestones),
            "6": ("Add reflection note", self.add_reflection),
            "7": ("Search & filter", self.search),
            "8": ("Executive summary", self.show_summary),
            "9": ("Warnings & alerts", self.show_warnings),
            "10": ("Charts", self.show_charts),
            "11": ("Export reports (MD / TXT / CSV)", self.export),
            "12": ("Import legacy CSV", self.import_csv),
            "13": ("Load sample dataset (40 goals)", self.load_sample),
            "14": ("Delete a goal", self.delete_goal),
            "g": ("Open graphical interface (Tkinter)", self.open_gui),
            "0": ("Exit", None),
        }
        while True:
            self.print_menu(actions)
            try:
                choice = input(paint("  Select an option: ", "bold")).strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if choice == "0":
                break
            if choice not in actions:
                err("Invalid choice - please pick a number from the menu.")
                continue
            try:
                actions[choice][1]()
            except Cancelled:
                print()
                note("Cancelled - back to the menu.")
            except KeyboardInterrupt:
                print()
                note("Interrupted - back to the menu.")
            except (GoalManagerError, GoalNotFound, ValidationError) as exc:
                err(str(exc))
            except OSError as exc:
                err(f"File problem: {exc}")
        print(paint(f"\n  Goals are saved in {self.m.storage.path}. Keep going - see you soon!\n", "green"))

    def welcome(self) -> None:
        print(paint(BANNER, "cyan", "bold") if USE_COLOR else BANNER)
        print(paint(f"  {APP_NAME} - track goals, milestones, progress and reflections", "bold"))
        print(paint("  Tip: type :q at any prompt to cancel the current action.", "dim"))
        for message in self.m.load_messages:
            print(paint(f"  ! {message}", "yellow"))

    def print_menu(self, actions) -> None:
        s = self.m.summary()
        heading("MAIN MENU")
        print(paint(f"  {s['total']} goals | {s['completed']} completed | {s['overdue']} overdue | "
                    f"avg {s['avg_completion']}% | health: {s['health']}", "dim"))
        warns = self.m.warnings()
        critical = sum(1 for w in warns if w.level == "CRITICAL")
        if warns:
            print(paint(f"  ! {len(warns)} warning(s), {critical} critical - choose 9 to review", "yellow"))
        print()
        for key, (label, _) in actions.items():
            print(f"   {paint(key.upper().rjust(2), 'bold', 'cyan')}  {label}")
        print()

    # ---- goals --------------------------------------------------------------
    def add_goal(self) -> None:
        heading("Add a new goal")
        note("Press Enter to accept a [default].  Dates: YYYY-MM-DD (DD/MM/YYYY also works).")
        today = self.m.today
        title = ask("Title (3-80 chars)", validate_title)
        existing = self.m.categories()
        if existing:
            note("Existing categories: " + ", ".join(existing))
        category = ask("Category", validate_category, default="General")
        priority = ask("Priority (Low / Medium / High)", validate_priority, default="Medium")
        start = ask("Start date", lambda v: validate_date(v, label="Start date"),
                    default=today.strftime(DATE_FMT))

        def deadline_check(raw: str) -> str:
            value = validate_date(raw, label="Deadline")
            validate_date_order(start, value)
            return value
        deadline = ask("Deadline", deadline_check, default=(today + timedelta(days=30)).strftime(DATE_FMT))
        description = ask("Description", validate_description, allow_blank=True)
        milestones: List[str] = []
        note("Add milestones one per line - progress is then calculated automatically. Blank line = done.")
        while len(milestones) < 20:
            title_m = ask(f"Milestone {len(milestones) + 1}", validate_milestone_title, allow_blank=True)
            if not title_m:
                break
            if title_m.lower() in (x.lower() for x in milestones):
                err("That milestone is already in the list.")
                continue
            milestones.append(title_m)
        progress = 0
        if not milestones:
            progress = ask("Current progress %", validate_progress, default="0")
        goal = self.m.add_goal(title, category, priority, start, deadline, description, progress, milestones)
        ok(f"Goal #{goal.id} saved - '{goal.title}' ({goal.completion:.0f}% complete).")

    def list_goals(self) -> None:
        heading("All goals")
        sort_by = ask("Sort by (deadline / completion / title / priority / id)",
                      self._sort_validator, default="deadline")
        print_goal_table(self.m.search(sort_by=sort_by), self.m.today)

    @staticmethod
    def _sort_validator(raw: str) -> str:
        value = raw.strip().lower()
        if value not in ("deadline", "completion", "title", "priority", "id"):
            raise ValidationError("Choose deadline, completion, title, priority or id.")
        return value

    def view_goal(self) -> None:
        heading("Goal details")
        if 0 < len(self.m.goals) <= PAGE_SIZE:
            print_goal_table(self.m.sort_goals(self.m.goals, "id"), self.m.today)
        goal = ask_goal(self.m)
        print_goal_detail(goal, self.m.today)

    def edit_goal(self) -> None:
        heading("Edit goal / update progress")
        goal = ask_goal(self.m)
        print_goal_detail(goal, self.m.today)
        fields = {
            "1": "Title", "2": "Category", "3": "Priority", "4": "Start date", "5": "Deadline",
            "6": "Description", "7": "Progress %", "8": "Mark as completed",
        }
        print()
        for key, label in fields.items():
            print(f"   {key}  {label}")
        pick = ask("Field to change", lambda v: validate_int_range(v, 1, 8, "Choice"))
        gid = goal.id
        if pick == 1:
            self.m.update_goal(gid, title=ask("New title", validate_title, default=goal.title))
        elif pick == 2:
            self.m.update_goal(gid, category=ask("New category", validate_category, default=goal.category))
        elif pick == 3:
            self.m.update_goal(gid, priority=ask("New priority", validate_priority, default=goal.priority))
        elif pick == 4:
            self.m.update_goal(gid, start_date=ask("New start date", lambda v: validate_date(v, label="Start date"),
                                                   default=goal.start_date))
        elif pick == 5:
            self.m.update_goal(gid, deadline=ask("New deadline", lambda v: validate_date(v, label="Deadline"),
                                                 default=goal.deadline))
        elif pick == 6:
            self.m.update_goal(gid, description=ask("New description", validate_description, allow_blank=True))
        elif pick == 7:
            if goal.milestones:
                raise GoalManagerError("This goal's progress is calculated from its milestones - use option 5 "
                                       "in the main menu to tick them off.")
            self.m.update_goal(gid, progress=ask("New progress %", validate_progress, default=int(goal.progress)))
        else:
            if ask_yes_no(f"Mark '{goal.title}' as 100% complete"):
                self.m.complete_goal(gid)
        ok("Goal updated.")
        goal = self.m.get(gid)
        print(f"  Now {progress_bar(goal.completion)} {goal.completion:.0f}% - {goal.status(self.m.today)}")

    def delete_goal(self) -> None:
        heading("Delete a goal")
        goal = ask_goal(self.m)
        if ask_yes_no(f"Permanently delete #{goal.id} '{goal.title}'"):
            self.m.delete_goal(goal.id)
            ok("Goal deleted.")
        else:
            note("Nothing deleted.")

    # ---- milestones & reflections -------------------------------------------
    def manage_milestones(self) -> None:
        heading("Manage milestones")
        goal = ask_goal(self.m)
        while True:
            goal = self.m.get(goal.id)
            print_goal_detail(goal, self.m.today)
            print("\n   A  Add milestone    T  Toggle done/undone    R  Remove milestone    B  Back")
            choice = ask("Action", lambda v: self._one_of(v, "atrb"))
            if choice == "b":
                return
            if choice == "a":
                self.m.add_milestone(goal.id, ask("Milestone title", validate_milestone_title))
                ok("Milestone added.")
            elif not goal.milestones:
                err("This goal has no milestones yet.")
            else:
                number = ask(f"Milestone number (1-{len(goal.milestones)})",
                             lambda v: validate_int_range(v, 1, len(goal.milestones), "Milestone number"))
                if choice == "t":
                    updated = self.m.toggle_milestone(goal.id, number - 1)
                    ok(f"Completion is now {updated.completion:.0f}%.")
                else:
                    self.m.remove_milestone(goal.id, number - 1)
                    ok("Milestone removed.")

    @staticmethod
    def _one_of(raw: str, letters: str) -> str:
        value = raw.strip().lower()
        if len(value) != 1 or value not in letters:
            raise ValidationError("Choose one of: " + ", ".join(letters.upper()))
        return value

    def add_reflection(self) -> None:
        heading("Add reflection note")
        goal = ask_goal(self.m)
        if goal.reflections:
            note("Latest note: " + goal.reflections[-1].note)
        text = ask("Reflection (what went well / what to change)", validate_note)
        self.m.add_reflection(goal.id, text)
        ok("Reflection saved.")

    # ---- search ----------------------------------------------------------------
    def search(self) -> None:
        heading("Search & filter")
        note("Leave a filter blank to ignore it.")
        keyword = ask("Keyword(s)", validate_keyword, allow_blank=True)
        cats = self.m.categories()
        if cats:
            note("Categories: " + ", ".join(cats))
        category = ask("Category", lambda v: v.strip(), allow_blank=True)
        status = ask("Status (not started / in progress / completed / overdue)", validate_status_filter,
                     allow_blank=True)
        priority = ask("Priority (L / M / H)", validate_priority_filter, allow_blank=True)
        results = self.m.search(keyword, category, status, priority)
        heading(f"{len(results)} match(es)")
        print_goal_table(results, self.m.today)
        if results and ask_yes_no("Open one of these goals", default=False):
            print_goal_detail(ask_goal(self.m), self.m.today)

    # ---- analytics ---------------------------------------------------------------
    def show_summary(self) -> None:
        s = self.m.summary()
        heading(f"Executive summary (as of {s['as_of']})")
        if not s["total"]:
            note("No goals yet - add one (option 1) or load the sample dataset (option 13).")
            return
        health_style = {"On track": ("green",), "At risk": ("yellow",), "Critical": ("red", "bold")}.get(
            s["health"], ("cyan",))
        print(f"  Total goals        : {s['total']}")
        print(f"  Completed          : {paint(str(s['completed']), 'green')}   "
              f"In progress: {paint(str(s['in_progress']), 'yellow')}   "
              f"Not started: {s['not_started']}   Overdue: {paint(str(s['overdue']), 'red')}")
        print(f"  Average completion : {progress_bar(s['avg_completion'])} {s['avg_completion']}%")
        print(f"  Completion rate    : {s['completion_rate']}%")
        print(f"  Milestones         : {s['milestones_done']}/{s['milestones_total']} done")
        print(f"  Reflections        : {s['reflections_total']} ({s['reflections_30d']} in the last 30 days)")
        print(f"  Overall health     : {paint(s['health'], *health_style)}")

        print("\n  " + paint("By category", "bold"))
        print(f"  {'Category':<14}{'Goals':>6}{'Avg %':>8}{'Done':>6}{'Overdue':>9}")
        for cat, d in s["by_category"].items():
            print(f"  {trunc(cat, 13):<14}{d['count']:>6}{d['avg_completion']:>8}{d['completed']:>6}{d['overdue']:>9}")

        print("\n  " + paint("By priority", "bold"))
        for pri, d in s["by_priority"].items():
            print(f"  {pri:<8}{d['count']:>3} goals   avg {d['avg_completion']}%")

        print("\n  " + paint("Monthly trend (goals started / completed)", "bold"))
        for m in s["monthly"]:
            print(f"  {m['month']}  started {m['started']:>2}  completed {m['completed']:>2}")

        print("\n  " + paint("Key trends", "bold"))
        for line in s["insights"]:
            print(f"   \u2022 {line}")

    def show_warnings(self) -> None:
        heading("Warnings & alerts")
        warns = self.m.warnings()
        if not warns:
            ok("No warnings - all goals look healthy.")
            return
        counts = {lvl: sum(1 for w in warns if w.level == lvl) for lvl in ("CRITICAL", "WARNING", "INFO")}
        print(f"  {counts['CRITICAL']} critical, {counts['WARNING']} warning, {counts['INFO']} info\n")
        for w in warns:
            tag = paint(f"[{w.level:<8}]", *_LEVEL_STYLE[w.level])
            ref = f"#{w.goal_id} {trunc(w.title, 30)}: " if w.goal_id else f"{w.title}: "
            print(f"  {tag} {ref}{w.message}")

    def show_charts(self) -> None:
        s = self.m.summary()
        heading("Charts")
        if not s["total"]:
            note("No data to chart yet.")
            return
        print("  " + paint("Average completion by category", "bold"))
        for line in charts.text_bars([(c, d["avg_completion"]) for c, d in s["by_category"].items()]):
            print("  " + line)
        print("\n  " + paint("Goals by status", "bold"))
        biggest = max(s["by_status"].values()) or 1
        for line in charts.text_bars(s["by_status"].items(), max_value=biggest, suffix=""):
            print("  " + line)
        print("\n  " + paint("Completed per month", "bold"))
        peak = max([m["completed"] for m in s["monthly"]] + [1])
        for line in charts.text_bars([(m["month"], m["completed"]) for m in s["monthly"]],
                                     max_value=peak, suffix=""):
            print("  " + line)
        if charts.matplotlib_available():
            if ask_yes_no("\n  Save these as a PNG chart", default=False):
                path = charts.save_summary_chart(self.m, self.export_dir / "summary_chart.png")
                ok(f"Chart saved to {path}")
        else:
            note("Install matplotlib (pip install matplotlib) to also save a PNG chart.")

    # ---- export / import ---------------------------------------------------------
    def export(self) -> None:
        heading("Export reports")
        if not self.m.goals:
            note("Nothing to export yet.")
            return
        for path in reports.export_all(self.m, self.export_dir):
            ok(f"Wrote {path}")

    def import_csv(self) -> None:
        heading("Import legacy CSV")
        sample = self.data_dir / "legacy_import_sample.csv"
        note("Required columns: title, deadline.  Optional: category, priority, start_date, progress,")
        note("milestones, reflections, description.  Common aliases (goal, due_date, percent...) work too.")

        def check_path(raw: str) -> Path:
            p = Path(raw.strip().strip('"').strip("'")).expanduser()
            if not p.is_file():
                raise ValidationError(f"File not found: {p}")
            return p
        path = ask("CSV file path", check_path, default=str(sample) if sample.exists() else None)
        result = importer.import_csv(self.m, path, self.export_dir)
        if not result.ok:
            err(result.fatal)
            return
        print(f"  Rows read: {result.total_rows}   Imported: {result.imported}   Skipped: {result.skipped}")
        if result.imported:
            ok(f"{result.imported} goal(s) imported.")
        for line, message in result.errors[:15]:
            print(paint(f"   line {line}: ", "yellow") + message)
        if len(result.errors) > 15:
            note(f"... and {len(result.errors) - 15} more (see the log).")
        if result.log_path:
            note(f"Full row-by-row error log: {result.log_path}")

    def load_sample(self) -> None:
        heading("Load sample dataset")
        if self.m.goals and not ask_yes_no(f"You already have {len(self.m.goals)} goal(s). Add 40 sample goals too"):
            note("Nothing loaded.")
            return
        self.m.add_many(seed.generate_sample_goals(self.m.today))
        ok("40 sample goals added. Try the summary (8), warnings (9) and charts (10).")

    def open_gui(self) -> None:
        try:
            from .gui import launch_gui
        except ImportError:
            err("Tkinter is not available in this Python installation.")
            note("Linux: sudo apt install python3-tk   |   Windows/macOS: reinstall Python with Tcl/Tk.")
            return
        note("Opening the graphical interface - close its window to return here.")
        launch_gui(self.m, self.export_dir, self.data_dir)
        self.m.reload()


def run_cli(manager: GoalManager, export_dir, data_dir) -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # box characters on any console
    except (AttributeError, ValueError):
        pass
    App(manager, export_dir, data_dir).run()
