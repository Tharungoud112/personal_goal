"""Tkinter graphical interface (standard library only - no extra packages needed).

Tabs: Goals (search/filter, details, milestones, reflections), Dashboard (summary cards and
charts drawn on Canvas) and Warnings.  Uses exactly the same logic engine and validators as the
terminal interface, so both front-ends always agree.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tkinter as tk
from datetime import timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import List, Optional, Tuple

from . import charts, importer, reports, seed
from .logic import GoalManager, GoalManagerError, GoalNotFound
from .models import (
    Goal,
    STATUS_COMPLETED,
    STATUS_IN_PROGRESS,
    STATUS_NOT_STARTED,
    STATUS_OVERDUE,
)
from .validation import (
    DATE_FMT,
    PRIORITIES,
    STATUSES,
    ValidationError,
    validate_category,
    validate_date,
    validate_date_order,
    validate_description,
    validate_milestone_title,
    validate_priority,
    validate_progress,
    validate_title,
)

C = {
    "bg": "#f4f6fb", "card": "#ffffff", "primary": "#1f3a5f", "accent": "#2e86de",
    "good": "#27ae60", "warn": "#f39c12", "bad": "#e74c3c", "muted": "#7f8c8d",
    "border": "#d5dbe6", "text": "#2c3e50",
}
STATUS_COLOR = {STATUS_COMPLETED: C["good"], STATUS_IN_PROGRESS: C["warn"],
                STATUS_OVERDUE: C["bad"], STATUS_NOT_STARTED: C["muted"]}
LEVEL_COLOR = {"CRITICAL": C["bad"], "WARNING": "#d68910", "INFO": C["accent"]}
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 16, "bold")


# ============================================================================= charts
class HBarChart(tk.Canvas):
    """Horizontal bar chart drawn on a Canvas; redraws itself when resized."""

    def __init__(self, parent, title: str, **kwargs):
        super().__init__(parent, bg=C["card"], highlightthickness=1, highlightbackground=C["border"], **kwargs)
        self.title = title
        self.items: List[Tuple[str, float]] = []
        self.max_value = 100.0
        self.fmt = "{:.0f}%"
        self.colors: Optional[List[str]] = None
        self.bind("<Configure>", lambda _e: self.redraw())

    def set_items(self, items, max_value: float = 100.0, fmt: str = "{:.0f}%", colors=None) -> None:
        self.items, self.max_value, self.fmt, self.colors = list(items), max(max_value, 1e-9), fmt, colors
        self.redraw()

    def redraw(self) -> None:
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 80 or h < 60:
            return
        self.create_text(12, 14, text=self.title, anchor="w", font=FONT_BOLD, fill=C["text"])
        if not self.items:
            self.create_text(w / 2, h / 2, text="No data yet", fill=C["muted"], font=FONT)
            return
        top, label_w, right = 34, 96, 52
        row_h = min(28.0, (h - top - 8) / len(self.items))
        bar_h = max(6.0, row_h * 0.6)
        span = max(w - label_w - right - 12, 10)
        for i, (label, value) in enumerate(self.items):
            y = top + i * row_h + row_h / 2
            color = self.colors[i] if self.colors else C["accent"]
            self.create_text(12, y, text=label[:14], anchor="w", font=("Segoe UI", 9), fill=C["text"])
            self.create_rectangle(label_w, y - bar_h / 2, label_w + span, y + bar_h / 2,
                                  fill="#e9edf5", outline="")
            length = span * max(0.0, min(value, self.max_value)) / self.max_value
            if length > 0:
                self.create_rectangle(label_w, y - bar_h / 2, label_w + length, y + bar_h / 2,
                                      fill=color, outline="")
            self.create_text(label_w + span + 8, y, text=self.fmt.format(value), anchor="w",
                             font=("Segoe UI", 9, "bold"), fill=C["text"])


class TrendChart(tk.Canvas):
    """Grouped vertical bars: goals started vs completed per month."""

    def __init__(self, parent, title: str, **kwargs):
        super().__init__(parent, bg=C["card"], highlightthickness=1, highlightbackground=C["border"], **kwargs)
        self.title = title
        self.months: List[dict] = []
        self.bind("<Configure>", lambda _e: self.redraw())

    def set_months(self, months) -> None:
        self.months = list(months)
        self.redraw()

    def redraw(self) -> None:
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 120 or h < 100:
            return
        self.create_text(12, 14, text=self.title, anchor="w", font=FONT_BOLD, fill=C["text"])
        # legend
        self.create_rectangle(w - 170, 8, w - 160, 18, fill=C["accent"], outline="")
        self.create_text(w - 156, 13, text="Started", anchor="w", font=("Segoe UI", 8), fill=C["text"])
        self.create_rectangle(w - 100, 8, w - 90, 18, fill=C["good"], outline="")
        self.create_text(w - 86, 13, text="Completed", anchor="w", font=("Segoe UI", 8), fill=C["text"])
        if not self.months:
            return
        peak = max([m["started"] for m in self.months] + [m["completed"] for m in self.months] + [1])
        left, bottom, top = 30, h - 26, 40
        plot_h = bottom - top
        slot = (w - left - 14) / len(self.months)
        bar_w = min(26.0, slot / 3)
        self.create_line(left, bottom, w - 10, bottom, fill=C["border"])
        for i, m in enumerate(self.months):
            cx = left + slot * i + slot / 2
            for offset, key, color in ((-bar_w / 2 - 1, "started", C["accent"]), (bar_w / 2 + 1, "completed", C["good"])):
                value = m[key]
                bar_top = bottom - plot_h * value / peak
                self.create_rectangle(cx + offset - bar_w / 2, bar_top, cx + offset + bar_w / 2, bottom,
                                      fill=color, outline="")
                if value:
                    self.create_text(cx + offset, bar_top - 8, text=str(value), font=("Segoe UI", 8), fill=C["text"])
            self.create_text(cx, bottom + 12, text=m["month"][2:], font=("Segoe UI", 8), fill=C["muted"])


# ============================================================================= dialog
class GoalDialog(tk.Toplevel):
    """Modal form used for both adding and editing a goal."""

    def __init__(self, parent, manager: GoalManager, goal: Optional[Goal] = None):
        super().__init__(parent)
        self.manager, self.goal = manager, goal
        self.saved: Optional[Goal] = None
        self.title("Edit goal" if goal else "Add a new goal")
        self.configure(bg=C["bg"], padx=18, pady=14)
        self.resizable(False, False)
        self.transient(parent)

        today = manager.today
        frm = ttk.Frame(self)
        frm.pack(fill="both", expand=True)
        frm.columnconfigure(1, weight=1)

        self.v_title = tk.StringVar(value=goal.title if goal else "")
        self.v_cat = tk.StringVar(value=goal.category if goal else "General")
        self.v_pri = tk.StringVar(value=goal.priority if goal else "Medium")
        self.v_start = tk.StringVar(value=goal.start_date if goal else today.strftime(DATE_FMT))
        self.v_due = tk.StringVar(value=goal.deadline if goal else (today + timedelta(days=30)).strftime(DATE_FMT))
        self.v_desc = tk.StringVar(value=goal.description if goal else "")
        self.v_prog = tk.IntVar(value=int(goal.progress) if goal else 0)

        rows = [("Title *", ttk.Entry(frm, textvariable=self.v_title, width=46)),
                ("Category *", ttk.Combobox(frm, textvariable=self.v_cat, values=manager.categories() or ["General"],
                                            width=43)),
                ("Priority *", ttk.Combobox(frm, textvariable=self.v_pri, values=PRIORITIES, state="readonly",
                                            width=43)),
                ("Start date *", ttk.Entry(frm, textvariable=self.v_start, width=46)),
                ("Deadline *", ttk.Entry(frm, textvariable=self.v_due, width=46)),
                ("Description", ttk.Entry(frm, textvariable=self.v_desc, width=46))]
        for r, (label, widget) in enumerate(rows):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 10))
            widget.grid(row=r, column=1, sticky="ew", pady=4)
        rows[0][1].focus_set()

        r = len(rows)
        has_milestones = bool(goal and goal.milestones)
        if goal is None:
            ttk.Label(frm, text="Milestones\n(one per line)").grid(row=r, column=0, sticky="nw", pady=4)
            self.t_ms = tk.Text(frm, width=46, height=5, font=FONT, relief="solid", borderwidth=1)
            self.t_ms.grid(row=r, column=1, sticky="ew", pady=4)
            r += 1
        else:
            self.t_ms = None
        ttk.Label(frm, text="Progress %").grid(row=r, column=0, sticky="w", pady=4)
        self.s_prog = ttk.Spinbox(frm, from_=0, to=100, textvariable=self.v_prog, width=8)
        self.s_prog.grid(row=r, column=1, sticky="w", pady=4)
        if has_milestones:
            self.s_prog.state(["disabled"])
            ttk.Label(frm, text="(calculated from milestones)", foreground=C["muted"]).grid(
                row=r, column=1, sticky="e")
        elif goal is None:
            ttk.Label(frm, text="(ignored if milestones are entered)", foreground=C["muted"]).grid(
                row=r, column=1, sticky="e")
        r += 1

        self.lbl_err = tk.Label(frm, text="", fg=C["bad"], bg=C["bg"], wraplength=420, justify="left", anchor="w")
        self.lbl_err.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        r += 1
        btns = ttk.Frame(frm)
        btns.grid(row=r, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(btns, text="Save", style="Accent.TButton", command=self.save).pack(side="right")
        self.bind("<Return>", self._on_return)
        self.bind("<Escape>", lambda _e: self.destroy())
        self.wait_visibility()
        self.grab_set()

    def _on_return(self, _event=None) -> None:
        if self.t_ms is not None and self.focus_get() is self.t_ms:
            return                                   # Enter inserts a newline in the milestones box
        self.save()

    def save(self) -> None:
        try:
            title = validate_title(self.v_title.get())
            category = validate_category(self.v_cat.get())
            priority = validate_priority(self.v_pri.get())
            start = validate_date(self.v_start.get(), label="Start date")
            deadline = validate_date(self.v_due.get(), label="Deadline")
            validate_date_order(start, deadline)
            description = validate_description(self.v_desc.get())
            try:
                progress = validate_progress(self.v_prog.get())
            except (tk.TclError, ValidationError):
                raise ValidationError("Progress must be a whole number between 0 and 100.")
            if self.goal is None:
                lines = [ln.strip() for ln in self.t_ms.get("1.0", "end").splitlines() if ln.strip()]
                seen = set()
                for ln in lines:
                    key = validate_milestone_title(ln).lower()
                    if key in seen:
                        raise ValidationError(f"Duplicate milestone: '{ln}'.")
                    seen.add(key)
                self.saved = self.manager.add_goal(title, category, priority, start, deadline,
                                                   description, progress, lines)
            else:
                changes = dict(title=title, category=category, priority=priority, start_date=start,
                               deadline=deadline, description=description)
                if not self.goal.milestones:
                    changes["progress"] = progress
                self.saved = self.manager.update_goal(self.goal.id, **changes)
        except (ValidationError, GoalManagerError) as exc:
            self.lbl_err.config(text="\u2716 " + str(exc))
            return
        self.destroy()


# ============================================================================= main window
class GoalReviewApp(tk.Tk):
    def __init__(self, manager: GoalManager, export_dir, data_dir):
        super().__init__()
        self.m = manager
        self.export_dir = Path(export_dir)
        self.data_dir = Path(data_dir)
        self.title("Personal Goal Review")
        self.geometry("1180x720")
        self.minsize(980, 600)
        self.configure(bg=C["bg"])
        self._style()
        self._build_menu()
        self._build_header()
        self._build_tabs()
        self.status = tk.StringVar(value="Ready.")
        tk.Label(self, textvariable=self.status, anchor="w", bg=C["border"], fg=C["text"], padx=10,
                 font=("Segoe UI", 9)).pack(side="bottom", fill="x")
        self.bind("<Control-n>", lambda _e: self.add_goal())
        self.bind("<F5>", lambda _e: self.refresh_all())
        self.refresh_all()
        for message in manager.load_messages:
            self.set_status(message)

    # ------------------------------------------------------------------ setup
    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", font=FONT, background=C["bg"], foreground=C["text"])
        style.configure("TFrame", background=C["bg"])
        style.configure("TLabel", background=C["bg"])
        style.configure("TNotebook", background=C["bg"], borderwidth=0)
        style.configure("TNotebook.Tab", padding=(18, 8), font=FONT_BOLD)
        style.configure("Treeview", rowheight=26, background=C["card"], fieldbackground=C["card"], borderwidth=0)
        style.configure("Treeview.Heading", font=FONT_BOLD, background=C["border"], foreground=C["primary"])
        style.map("Treeview", background=[("selected", "#cfe3fb")], foreground=[("selected", C["text"])])
        style.configure("TButton", padding=(10, 5))
        style.configure("Accent.TButton", background=C["accent"], foreground="white", font=FONT_BOLD)
        style.map("Accent.TButton", background=[("active", "#1b6cb8")])
        style.configure("Danger.TButton", foreground=C["bad"])
        style.configure("Card.TFrame", background=C["card"])
        style.configure("Horizontal.TProgressbar", troughcolor="#e9edf5", background=C["accent"], thickness=14)

    def _build_menu(self) -> None:
        menubar = tk.Menu(self)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Add goal\tCtrl+N", command=self.add_goal)
        file_menu.add_separator()
        file_menu.add_command(label="Import legacy CSV...", command=self.import_csv)
        file_menu.add_command(label="Export reports (MD / TXT / CSV)", command=self.export_reports)
        file_menu.add_command(label="Save chart as PNG...", command=self.save_chart)
        file_menu.add_separator()
        file_menu.add_command(label="Load sample dataset (40 goals)", command=self.load_sample)
        file_menu.add_command(label="Reload from disk\tF5", command=self.reload)
        file_menu.add_separator()
        file_menu.add_command(label="Quit", command=self.destroy)
        menubar.add_cascade(label="File", menu=file_menu)
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=lambda: messagebox.showinfo(
            "About", "Personal Goal Review\nHackathon Project #110 - LocalImpact Challenge\n\n"
                     "Track goals, milestones, completion % and reflection notes.", parent=self))
        menubar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menubar)

    def _build_header(self) -> None:
        header = tk.Frame(self, bg=C["primary"], padx=18, pady=12)
        header.pack(fill="x")
        tk.Label(header, text="\U0001F3AF  Personal Goal Review", font=FONT_TITLE, bg=C["primary"],
                 fg="white").pack(side="left")
        self.lbl_header = tk.Label(header, text="", font=FONT, bg=C["primary"], fg="#cfe3fb")
        self.lbl_header.pack(side="right")

    def _build_tabs(self) -> None:
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=12, pady=10)
        self.tab_goals, self.tab_dash, self.tab_warn = ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb)
        nb.add(self.tab_goals, text="  Goals  ")
        nb.add(self.tab_dash, text="  Dashboard  ")
        nb.add(self.tab_warn, text="  Warnings  ")
        self.notebook = nb
        self._build_goals_tab()
        self._build_dashboard_tab()
        self._build_warnings_tab()

    # --------------------------------------------------------------- goals tab
    def _build_goals_tab(self) -> None:
        pane = ttk.PanedWindow(self.tab_goals, orient="horizontal")
        pane.pack(fill="both", expand=True)
        left, right = ttk.Frame(pane), ttk.Frame(pane)
        pane.add(left, weight=3)
        pane.add(right, weight=2)

        bar = ttk.Frame(left)
        bar.pack(fill="x", pady=(0, 6))
        self.v_kw, self.v_fcat = tk.StringVar(), tk.StringVar()
        self.v_fstat, self.v_fpri, self.v_sort = tk.StringVar(), tk.StringVar(), tk.StringVar(value="deadline")
        ttk.Label(bar, text="Search").grid(row=0, column=0, sticky="w")
        ent = ttk.Entry(bar, textvariable=self.v_kw, width=22)
        ent.grid(row=1, column=0, padx=(0, 6))
        ent.bind("<KeyRelease>", lambda _e: self.refresh_goal_list())
        self.cb_cat = self._combo(bar, "Category", self.v_fcat, [""], 1, 14)
        self._combo(bar, "Status", self.v_fstat, [""] + list(STATUSES), 2, 12)
        self._combo(bar, "Priority", self.v_fpri, [""] + list(PRIORITIES), 3, 9)
        self._combo(bar, "Sort by", self.v_sort, ["deadline", "completion", "title", "priority", "id"], 4, 10)
        ttk.Button(bar, text="Clear", command=self.clear_filters).grid(row=1, column=5, padx=(4, 0))

        cols = ("id", "title", "category", "priority", "deadline", "done", "status")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        widths = {"id": 40, "title": 230, "category": 90, "priority": 65, "deadline": 85, "done": 55, "status": 90}
        for col in cols:
            self.tree.heading(col, text={"id": "ID", "done": "Done"}.get(col, col.title()))
            self.tree.column(col, width=widths[col], anchor="e" if col in ("id", "done") else "w",
                             stretch=(col == "title"))
        for status, color in STATUS_COLOR.items():
            self.tree.tag_configure(status, foreground=color)
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="left", fill="y")
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self.refresh_detail())
        self.tree.bind("<Double-1>", lambda _e: self.edit_goal())
        self.tree.bind("<Delete>", lambda _e: self.delete_goal())

        # detail panel
        btns = ttk.Frame(right)
        btns.pack(fill="x", pady=(0, 6))
        ttk.Button(btns, text="+ Add goal", style="Accent.TButton", command=self.add_goal).pack(side="left")
        ttk.Button(btns, text="Edit", command=self.edit_goal).pack(side="left", padx=4)
        ttk.Button(btns, text="Mark complete", command=self.complete_goal).pack(side="left")
        ttk.Button(btns, text="Delete", style="Danger.TButton", command=self.delete_goal).pack(side="right")

        card = tk.Frame(right, bg=C["card"], highlightthickness=1, highlightbackground=C["border"], padx=12, pady=10)
        card.pack(fill="both", expand=True)
        self.lbl_title = tk.Label(card, text="Select a goal", font=("Segoe UI", 13, "bold"), bg=C["card"],
                                  fg=C["primary"], anchor="w", justify="left", wraplength=380)
        self.lbl_title.pack(fill="x")
        self.lbl_meta = tk.Label(card, text="", font=("Segoe UI", 9), bg=C["card"], fg=C["muted"], anchor="w",
                                 justify="left", wraplength=380)
        self.lbl_meta.pack(fill="x", pady=(2, 6))
        self.pb = ttk.Progressbar(card, maximum=100, mode="determinate")
        self.pb.pack(fill="x")
        self.lbl_pct = tk.Label(card, text="", bg=C["card"], font=FONT_BOLD, anchor="w")
        self.lbl_pct.pack(fill="x", pady=(2, 4))

        prow = tk.Frame(card, bg=C["card"])
        prow.pack(fill="x")
        tk.Label(prow, text="Manual progress", bg=C["card"], font=("Segoe UI", 9)).pack(side="left")
        self.v_manual = tk.IntVar(value=0)
        self.scale = ttk.Scale(prow, from_=0, to=100, orient="horizontal", command=self._scale_moved)
        self.scale.pack(side="left", fill="x", expand=True, padx=8)
        self.lbl_scale = tk.Label(prow, text="0%", width=5, bg=C["card"])
        self.lbl_scale.pack(side="left")
        self.btn_apply = ttk.Button(prow, text="Apply", command=self.apply_progress)
        self.btn_apply.pack(side="left")

        tk.Label(card, text="Milestones (double-click to toggle)", bg=C["card"], font=("Segoe UI", 9, "bold"),
                 anchor="w").pack(fill="x", pady=(8, 2))
        mframe = tk.Frame(card, bg=C["card"])
        mframe.pack(fill="both", expand=True)
        self.lb = tk.Listbox(mframe, height=5, font=FONT, activestyle="none", relief="solid", borderwidth=1,
                             exportselection=False)
        self.lb.pack(side="left", fill="both", expand=True)
        self.lb.bind("<Double-1>", lambda _e: self.toggle_milestone())
        mbtns = tk.Frame(mframe, bg=C["card"])
        mbtns.pack(side="left", fill="y", padx=(6, 0))
        ttk.Button(mbtns, text="Toggle", command=self.toggle_milestone).pack(fill="x")
        ttk.Button(mbtns, text="Remove", command=self.remove_milestone).pack(fill="x", pady=4)
        arow = tk.Frame(card, bg=C["card"])
        arow.pack(fill="x", pady=(4, 0))
        self.v_new_ms = tk.StringVar()
        e1 = ttk.Entry(arow, textvariable=self.v_new_ms)
        e1.pack(side="left", fill="x", expand=True)
        e1.bind("<Return>", lambda _e: self.add_milestone())
        ttk.Button(arow, text="Add milestone", command=self.add_milestone).pack(side="left", padx=(6, 0))

        tk.Label(card, text="Reflection notes", bg=C["card"], font=("Segoe UI", 9, "bold"), anchor="w").pack(
            fill="x", pady=(8, 2))
        self.txt_ref = tk.Text(card, height=5, font=("Segoe UI", 9), wrap="word", relief="solid", borderwidth=1,
                               state="disabled", bg="#fbfcfe")
        self.txt_ref.pack(fill="both", expand=True)
        rrow = tk.Frame(card, bg=C["card"])
        rrow.pack(fill="x", pady=(4, 0))
        self.v_new_ref = tk.StringVar()
        e2 = ttk.Entry(rrow, textvariable=self.v_new_ref)
        e2.pack(side="left", fill="x", expand=True)
        e2.bind("<Return>", lambda _e: self.add_reflection())
        ttk.Button(rrow, text="Add note", command=self.add_reflection).pack(side="left", padx=(6, 0))

    def _combo(self, parent, label, var, values, column, width):
        ttk.Label(parent, text=label).grid(row=0, column=column, sticky="w")
        combo = ttk.Combobox(parent, textvariable=var, values=values, state="readonly", width=width)
        combo.grid(row=1, column=column, padx=(0, 6))
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh_goal_list())
        return combo

    # ------------------------------------------------------------ dashboard tab
    def _build_dashboard_tab(self) -> None:
        self.cards = {}
        row = ttk.Frame(self.tab_dash)
        row.pack(fill="x", pady=(2, 8))
        for key, caption in (("total", "Total goals"), ("completed", "Completed"), ("in_progress", "In progress"),
                             ("overdue", "Overdue"), ("avg", "Avg completion"), ("health", "Health")):
            box = tk.Frame(row, bg=C["card"], highlightthickness=1, highlightbackground=C["border"], padx=14, pady=10)
            box.pack(side="left", fill="x", expand=True, padx=4)
            value = tk.Label(box, text="-", font=("Segoe UI", 20, "bold"), bg=C["card"], fg=C["primary"])
            value.pack()
            tk.Label(box, text=caption, font=("Segoe UI", 9), bg=C["card"], fg=C["muted"]).pack()
            self.cards[key] = value

        grid = ttk.Frame(self.tab_dash)
        grid.pack(fill="both", expand=True)
        grid.columnconfigure((0, 1), weight=1, uniform="col")
        grid.rowconfigure((0, 1), weight=1, uniform="row")
        self.chart_cat = HBarChart(grid, "Average completion by category")
        self.chart_cat.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        self.chart_status = HBarChart(grid, "Goals by status")
        self.chart_status.grid(row=0, column=1, sticky="nsew", padx=4, pady=4)
        self.chart_trend = TrendChart(grid, "Monthly trend")
        self.chart_trend.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        ins = tk.Frame(grid, bg=C["card"], highlightthickness=1, highlightbackground=C["border"], padx=12, pady=8)
        ins.grid(row=1, column=1, sticky="nsew", padx=4, pady=4)
        tk.Label(ins, text="Key trends", font=FONT_BOLD, bg=C["card"], anchor="w").pack(fill="x")
        self.lbl_insights = tk.Label(ins, text="", font=("Segoe UI", 9), bg=C["card"], justify="left", anchor="nw",
                                     wraplength=430)
        self.lbl_insights.pack(fill="both", expand=True, pady=(4, 0))

    # ------------------------------------------------------------ warnings tab
    def _build_warnings_tab(self) -> None:
        top = ttk.Frame(self.tab_warn)
        top.pack(fill="x", pady=(2, 6))
        self.lbl_warn = ttk.Label(top, text="", font=FONT_BOLD)
        self.lbl_warn.pack(side="left")
        cols = ("level", "goal", "message")
        self.wtree = ttk.Treeview(self.tab_warn, columns=cols, show="headings", selectmode="browse")
        for col, width in (("level", 90), ("goal", 260), ("message", 640)):
            self.wtree.heading(col, text=col.title())
            self.wtree.column(col, width=width, anchor="w", stretch=(col == "message"))
        for level, color in LEVEL_COLOR.items():
            self.wtree.tag_configure(level, foreground=color)
        self.wtree.pack(fill="both", expand=True)
        self.wtree.bind("<Double-1>", self._jump_to_warning_goal)

    def _jump_to_warning_goal(self, _event=None) -> None:
        sel = self.wtree.selection()
        if not sel:
            return
        gid = self.wtree.set(sel[0], "goal").split(" ")[0].lstrip("#")
        if gid.isdigit() and self.tree.exists(gid):
            self.clear_filters()
            self.notebook.select(self.tab_goals)
            self.tree.selection_set(gid)
            self.tree.see(gid)

    # ---------------------------------------------------------------- refresh
    def set_status(self, text: str) -> None:
        self.status.set(text)

    def refresh_all(self) -> None:
        cats = self.m.categories()
        self.cb_cat.configure(values=[""] + cats)
        self.refresh_goal_list()
        self.refresh_dashboard()
        self.refresh_warnings()

    def refresh_goal_list(self) -> None:
        selected = self.selected_id()
        for item in self.tree.get_children():
            self.tree.delete(item)
        today = self.m.today
        try:
            goals = self.m.search(self.v_kw.get(), self.v_fcat.get(), self.v_fstat.get(),
                                  self.v_fpri.get(), self.v_sort.get() or "deadline")
        except ValidationError:
            goals = []
        for g in goals:
            st = g.status(today)
            self.tree.insert("", "end", iid=str(g.id), tags=(st,),
                             values=(g.id, g.title, g.category, g.priority, g.deadline, f"{g.completion:.0f}%", st))
        if selected is not None and self.tree.exists(str(selected)):
            self.tree.selection_set(str(selected))
        self.refresh_detail()
        self.set_status(f"{len(goals)} of {len(self.m.goals)} goal(s) shown.")

    def refresh_dashboard(self) -> None:
        s = self.m.summary()
        self.cards["total"].config(text=str(s["total"]))
        self.cards["completed"].config(text=str(s["completed"]), fg=C["good"])
        self.cards["in_progress"].config(text=str(s["in_progress"]), fg=C["warn"])
        self.cards["overdue"].config(text=str(s["overdue"]), fg=C["bad"] if s["overdue"] else C["primary"])
        self.cards["avg"].config(text=f"{s['avg_completion']:.0f}%")
        health_color = {"On track": C["good"], "At risk": C["warn"], "Critical": C["bad"]}.get(s["health"], C["primary"])
        self.cards["health"].config(text=s["health"], fg=health_color, font=("Segoe UI", 14, "bold"))
        self.lbl_header.config(text=f"{s['total']} goals  |  {s['completed']} completed  |  {s['overdue']} overdue")
        self.chart_cat.set_items([(c, d["avg_completion"]) for c, d in s["by_category"].items()])
        order = [STATUS_NOT_STARTED, STATUS_IN_PROGRESS, STATUS_COMPLETED, STATUS_OVERDUE]
        self.chart_status.set_items([(k, s["by_status"][k]) for k in order],
                                    max_value=max(max(s["by_status"].values()), 1), fmt="{:.0f}",
                                    colors=[STATUS_COLOR[k] for k in order])
        self.chart_trend.set_months(s["monthly"])
        self.lbl_insights.config(text="\n".join("\u2022 " + line for line in s["insights"]) if s["total"]
                                 else "No goals yet. Add one, or use File > Load sample dataset.")

    def refresh_warnings(self) -> None:
        for item in self.wtree.get_children():
            self.wtree.delete(item)
        warns = self.m.warnings()
        for w in warns:
            ref = f"#{w.goal_id} {w.title}" if w.goal_id else w.title
            self.wtree.insert("", "end", values=(w.level, ref, w.message), tags=(w.level,))
        crit = sum(1 for w in warns if w.level == "CRITICAL")
        self.lbl_warn.config(text=(f"{len(warns)} warning(s), {crit} critical  (double-click a row to open the goal)"
                                   if warns else "No warnings - all goals look healthy."))
        self.notebook.tab(self.tab_warn, text=f"  Warnings ({len(warns)})  " if warns else "  Warnings  ")

    # ----------------------------------------------------------------- detail
    def selected_id(self) -> Optional[int]:
        sel = self.tree.selection()
        return int(sel[0]) if sel else None

    def selected_goal(self, required: bool = True) -> Optional[Goal]:
        gid = self.selected_id()
        if gid is None:
            if required:
                messagebox.showinfo("Select a goal", "Please select a goal in the list first.", parent=self)
            return None
        try:
            return self.m.get(gid)
        except GoalNotFound:
            return None

    def refresh_detail(self) -> None:
        goal = self.selected_goal(required=False)
        self.lb.delete(0, "end")
        self.txt_ref.config(state="normal")
        self.txt_ref.delete("1.0", "end")
        if goal is None:
            self.lbl_title.config(text="Select a goal")
            self.lbl_meta.config(text="")
            self.pb["value"] = 0
            self.lbl_pct.config(text="")
            self.scale.state(["disabled"])
            self.btn_apply.state(["disabled"])
            self.txt_ref.config(state="disabled")
            return
        today = self.m.today
        status = goal.status(today)
        left = goal.days_left(today)
        due = ("done" if status == STATUS_COMPLETED else
               f"{abs(left)} day(s) overdue" if left < 0 else "due today" if left == 0 else f"{left} day(s) left")
        self.lbl_title.config(text=f"#{goal.id}  {goal.title}")
        meta = (f"{goal.category}  |  {goal.priority} priority  |  {goal.start_date} \u2192 {goal.deadline} ({due})"
                + (f"\n{goal.description}" if goal.description else ""))
        self.lbl_meta.config(text=meta)
        self.pb["value"] = goal.completion
        self.lbl_pct.config(text=f"{goal.completion:.0f}% complete  -  {status}", fg=STATUS_COLOR[status])
        for m in goal.milestones:
            self.lb.insert("end", ("\u2611  " if m.done else "\u2610  ") + m.title)
        manual = not goal.milestones
        self.scale.set(goal.progress)
        self.lbl_scale.config(text=f"{goal.progress}%")
        for widget in (self.scale, self.btn_apply):
            widget.state(["!disabled"] if manual else ["disabled"])
        for r in goal.reflections:
            self.txt_ref.insert("end", f"{r.date}  {r.note}\n")
        if not goal.reflections:
            self.txt_ref.insert("end", "No reflection notes yet.")
        self.txt_ref.config(state="disabled")

    def _scale_moved(self, value) -> None:
        self.lbl_scale.config(text=f"{int(float(value))}%")

    # ---------------------------------------------------------------- actions
    def _run(self, action, success: str = "") -> bool:
        """Run a manager call, showing validation/business errors in a dialog."""
        try:
            action()
        except (ValidationError, GoalManagerError, GoalNotFound) as exc:
            messagebox.showerror("Cannot do that", str(exc), parent=self)
            return False
        except OSError as exc:
            messagebox.showerror("File problem", str(exc), parent=self)
            return False
        if success:
            self.set_status(success)
        self.refresh_all()
        return True

    def add_goal(self) -> None:
        dialog = GoalDialog(self, self.m)
        self.wait_window(dialog)
        if dialog.saved:
            self.refresh_all()
            self.tree.selection_set(str(dialog.saved.id))
            self.tree.see(str(dialog.saved.id))
            self.set_status(f"Goal #{dialog.saved.id} added.")

    def edit_goal(self) -> None:
        goal = self.selected_goal()
        if goal is None:
            return
        dialog = GoalDialog(self, self.m, goal)
        self.wait_window(dialog)
        if dialog.saved:
            self.refresh_all()
            self.set_status(f"Goal #{goal.id} updated.")

    def delete_goal(self) -> None:
        goal = self.selected_goal()
        if goal and messagebox.askyesno("Delete goal", f"Permanently delete #{goal.id} '{goal.title}'?",
                                        icon="warning", parent=self):
            self._run(lambda: self.m.delete_goal(goal.id), f"Goal #{goal.id} deleted.")

    def complete_goal(self) -> None:
        goal = self.selected_goal()
        if goal:
            self._run(lambda: self.m.complete_goal(goal.id), f"Goal #{goal.id} marked complete.")

    def apply_progress(self) -> None:
        goal = self.selected_goal()
        if goal:
            value = int(float(self.scale.get()))
            self._run(lambda: self.m.set_progress(goal.id, value), f"Progress set to {value}%.")

    def add_milestone(self) -> None:
        goal = self.selected_goal()
        if goal and self._run(lambda: self.m.add_milestone(goal.id, self.v_new_ms.get()), "Milestone added."):
            self.v_new_ms.set("")

    def _selected_milestone(self) -> Optional[int]:
        sel = self.lb.curselection()
        if not sel:
            messagebox.showinfo("Select a milestone", "Please select a milestone first.", parent=self)
            return None
        return sel[0]

    def toggle_milestone(self) -> None:
        goal, index = self.selected_goal(), self._selected_milestone()
        if goal is not None and index is not None:
            self._run(lambda: self.m.toggle_milestone(goal.id, index))
            self.lb.selection_set(index)

    def remove_milestone(self) -> None:
        goal, index = self.selected_goal(), self._selected_milestone()
        if goal is not None and index is not None:
            self._run(lambda: self.m.remove_milestone(goal.id, index), "Milestone removed.")

    def add_reflection(self) -> None:
        goal = self.selected_goal()
        if goal and self._run(lambda: self.m.add_reflection(goal.id, self.v_new_ref.get()), "Reflection saved."):
            self.v_new_ref.set("")

    def clear_filters(self) -> None:
        for var in (self.v_kw, self.v_fcat, self.v_fstat, self.v_fpri):
            var.set("")
        self.v_sort.set("deadline")
        self.refresh_goal_list()

    # --------------------------------------------------------- file operations
    def import_csv(self) -> None:
        path = filedialog.askopenfilename(
            parent=self, title="Choose a CSV file to import", initialdir=str(self.data_dir),
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        result = importer.import_csv(self.m, path, self.export_dir)
        if not result.ok:
            messagebox.showerror("Import failed", result.fatal, parent=self)
            return
        lines = [f"Rows read: {result.total_rows}", f"Imported: {result.imported}", f"Skipped: {result.skipped}"]
        if result.errors:
            lines.append("")
            lines += [f"Line {ln}: {msg}" for ln, msg in result.errors[:8]]
            if len(result.errors) > 8:
                lines.append(f"... and {len(result.errors) - 8} more")
            lines.append(f"\nFull error log:\n{result.log_path}")
        (messagebox.showwarning if result.errors else messagebox.showinfo)("Import finished", "\n".join(lines),
                                                                         parent=self)
        self.refresh_all()

    def export_reports(self) -> None:
        if not self.m.goals:
            messagebox.showinfo("Nothing to export", "Add some goals first.", parent=self)
            return
        try:
            paths = reports.export_all(self.m, self.export_dir)
        except OSError as exc:
            messagebox.showerror("Export failed", str(exc), parent=self)
            return
        messagebox.showinfo("Reports exported", "Saved:\n\n" + "\n".join(str(p) for p in paths), parent=self)
        self._open_folder(self.export_dir)

    def save_chart(self) -> None:
        if not charts.matplotlib_available():
            messagebox.showinfo("Matplotlib not installed",
                                "PNG export needs Matplotlib:\n\n    pip install matplotlib\n\n"
                                "The on-screen Dashboard works without it.", parent=self)
            return
        path = filedialog.asksaveasfilename(parent=self, defaultextension=".png", initialdir=str(self.export_dir),
                                            initialfile="summary_chart.png", filetypes=[("PNG image", "*.png")])
        if path:
            try:
                charts.save_summary_chart(self.m, path)
                self.set_status(f"Chart saved to {path}")
            except Exception as exc:                     # matplotlib can raise many things
                messagebox.showerror("Chart failed", str(exc), parent=self)

    def load_sample(self) -> None:
        if self.m.goals and not messagebox.askyesno(
                "Load sample data", f"You already have {len(self.m.goals)} goal(s).\nAdd 40 sample goals as well?",
                parent=self):
            return
        self._run(lambda: self.m.add_many(seed.generate_sample_goals(self.m.today)), "40 sample goals added.")

    def reload(self) -> None:
        self._run(self.m.reload, "Reloaded from disk.")

    @staticmethod
    def _open_folder(path: Path) -> None:
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(path))                  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception:
            pass                                          # opening the folder is a convenience only


def launch_gui(manager: GoalManager, export_dir, data_dir) -> None:
    app = GoalReviewApp(manager, export_dir, data_dir)
    app.mainloop()
