"""CSV (de)serialisation for goals.

Milestones cell:   ``[x] Done item;[ ] Open item``   (plain ``Item`` = not done)
Reflections cell:  ``2026-01-05: note one | 2026-01-09: note two``
"""

from __future__ import annotations

import csv
from datetime import date, datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from .models import Goal, Milestone, Reflection
from .validation import (
    DATE_FMT,
    MAX_MILESTONES_PER_GOAL,
    ValidationError,
    sanitize_text,
    validate_category,
    validate_date,
    validate_date_order,
    validate_description,
    validate_milestone_title,
    validate_note,
    validate_priority,
    validate_progress,
    validate_title,
)

CSV_FIELDS = [
    "id", "title", "category", "priority", "start_date", "deadline", "progress",
    "completion", "status", "milestones", "reflections", "description",
    "created_at", "completed_on",
]
REQUIRED_COLUMNS = ("title", "deadline")

_ALIASES = {
    "goal": "title", "name": "title", "goal_title": "title",
    "type": "category", "due": "deadline", "due_date": "deadline", "end_date": "deadline",
    "start": "start_date", "percent": "progress", "percentage": "progress",
    "progress_%": "progress", "notes": "reflections", "reflection": "reflections",
    "milestone": "milestones", "desc": "description",
}


def normalise_header(name: Optional[str]) -> str:
    return sanitize_text(name or "").lower().replace(" ", "_")


def map_headers(fieldnames: Iterable[str]) -> Dict[str, str]:
    """Map raw CSV headers -> canonical column names (aliases applied when unambiguous)."""
    normalised = {raw: normalise_header(raw) for raw in fieldnames}
    present = set(normalised.values())
    mapping: Dict[str, str] = {}
    for raw, norm in normalised.items():
        target = _ALIASES.get(norm, norm)
        if norm == "completion" and "progress" not in present:
            target = "progress"
        if target != norm and target in present:      # alias would collide with a real column
            target = norm
        mapping[raw] = target
    return mapping


# --------------------------------------------------------------------------- export
def milestones_to_cell(goal: Goal) -> str:
    return ";".join(f"[{'x' if m.done else ' '}] {m.title}" for m in goal.milestones)


def reflections_to_cell(goal: Goal) -> str:
    return " | ".join(f"{r.date}: {r.note}" for r in goal.reflections)


def goal_to_row(goal: Goal, today: date) -> Dict[str, object]:
    return {
        "id": goal.id,
        "title": goal.title,
        "category": goal.category,
        "priority": goal.priority,
        "start_date": goal.start_date,
        "deadline": goal.deadline,
        "progress": goal.progress,
        "completion": goal.completion,
        "status": goal.status(today),
        "milestones": milestones_to_cell(goal),
        "reflections": reflections_to_cell(goal),
        "description": goal.description,
        "created_at": goal.created_at,
        "completed_on": goal.completed_on or "",
    }


def write_goals_csv(goals: Iterable[Goal], path, today: date) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for goal in goals:
            writer.writerow(goal_to_row(goal, today))
    return path


# --------------------------------------------------------------------------- import
def parse_milestones(cell: str) -> List[Milestone]:
    items: List[Milestone] = []
    for part in (cell or "").split(";"):
        part = part.strip()
        if not part:
            continue
        done = part[:3].lower() == "[x]"
        items.append(Milestone(validate_milestone_title(part), done))
    return items


def parse_reflections(cell: str, fallback_date: str) -> List[Reflection]:
    items: List[Reflection] = []
    for part in (cell or "").split(" | "):
        part = part.strip()
        if not part:
            continue
        when, note = fallback_date, part
        if len(part) > 12 and part[10:12] == ": ":
            try:
                when = validate_date(part[:10])
                note = part[12:]
            except ValidationError:
                when, note = fallback_date, part
        items.append(Reflection(when, validate_note(note)))
    return items


def row_to_goal(row: Dict[str, str], new_id: int, today: date) -> Goal:
    """Validate one CSV row (canonical column names) and build a Goal.

    All problems in the row are collected and reported together.
    """
    problems: List[str] = []

    def attempt(field_name, func, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValidationError as exc:
            problems.append(f"{field_name}: {exc}")
            return None

    get = lambda key: (row.get(key) or "").strip()
    today_iso = today.strftime(DATE_FMT)

    title = attempt("title", validate_title, get("title"))
    category = attempt("category", validate_category, get("category") or "General")
    priority = attempt("priority", validate_priority, get("priority") or "Medium")
    deadline = attempt("deadline", validate_date, get("deadline"), label="Deadline")
    start = attempt("start_date", validate_date, get("start_date") or today_iso, label="Start date")
    progress = attempt("progress", validate_progress, get("progress") or 0)
    description = attempt("description", validate_description, get("description"))
    completed_on = attempt("completed_on", validate_date, get("completed_on"), allow_blank=True,
                           label="Completed on") if get("completed_on") else ""

    milestones: List[Milestone] = []
    reflections: List[Reflection] = []
    try:
        milestones = parse_milestones(get("milestones"))
        if len(milestones) > MAX_MILESTONES_PER_GOAL:
            problems.append(f"milestones: at most {MAX_MILESTONES_PER_GOAL} allowed (got {len(milestones)})")
    except ValidationError as exc:
        problems.append(f"milestones: {exc}")
    try:
        reflections = parse_reflections(get("reflections"), start or today_iso)
    except ValidationError as exc:
        problems.append(f"reflections: {exc}")

    if start and deadline:
        try:
            validate_date_order(start, deadline)
        except ValidationError as exc:
            problems.append(str(exc))

    if problems:
        raise ValidationError("; ".join(problems))

    goal = Goal(
        id=new_id, title=title, category=category, priority=priority, start_date=start,
        deadline=deadline, progress=progress, description=description or "",
        milestones=milestones, reflections=reflections,
        created_at=datetime.now().isoformat(timespec="seconds"),
        completed_on=completed_on or None,
    )
    if goal.completion >= 100 and not goal.completed_on:
        goal.completed_on = today_iso
    elif goal.completion < 100:
        goal.completed_on = None
    return goal
