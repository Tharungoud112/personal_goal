"""Data model: Goal, Milestone, Reflection (plain dataclasses)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import List, Optional

from .validation import (
    ValidationError,
    parse_iso,
    validate_category,
    validate_date,
    validate_description,
    validate_milestone_title,
    validate_note,
    validate_priority,
    validate_progress,
    validate_title,
)

STATUS_NOT_STARTED = "Not Started"
STATUS_IN_PROGRESS = "In Progress"
STATUS_COMPLETED = "Completed"
STATUS_OVERDUE = "Overdue"


@dataclass
class Milestone:
    title: str
    done: bool = False

    def to_dict(self) -> dict:
        return {"title": self.title, "done": bool(self.done)}


@dataclass
class Reflection:
    date: str
    note: str

    def to_dict(self) -> dict:
        return {"date": self.date, "note": self.note}


@dataclass
class Goal:
    id: int
    title: str
    category: str
    priority: str
    start_date: str
    deadline: str
    progress: int = 0                      # manual % - used only when there are no milestones
    description: str = ""
    milestones: List[Milestone] = field(default_factory=list)
    reflections: List[Reflection] = field(default_factory=list)
    created_at: str = ""
    completed_on: Optional[str] = None

    # ---- derived values -------------------------------------------------
    @property
    def total_milestones(self) -> int:
        return len(self.milestones)

    @property
    def done_milestones(self) -> int:
        return sum(1 for m in self.milestones if m.done)

    @property
    def completion(self) -> float:
        """Completion percentage: milestone-driven when milestones exist, else manual."""
        if self.milestones:
            return round(100.0 * self.done_milestones / len(self.milestones), 1)
        return float(self.progress)

    def days_left(self, today: date) -> int:
        return (parse_iso(self.deadline) - today).days

    def status(self, today: date) -> str:
        if self.completion >= 100:
            return STATUS_COMPLETED
        if parse_iso(self.deadline) < today:
            return STATUS_OVERDUE
        if self.completion > 0:
            return STATUS_IN_PROGRESS
        return STATUS_NOT_STARTED

    # ---- (de)serialisation ---------------------------------------------
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "category": self.category,
            "priority": self.priority,
            "start_date": self.start_date,
            "deadline": self.deadline,
            "progress": self.progress,
            "description": self.description,
            "milestones": [m.to_dict() for m in self.milestones],
            "reflections": [r.to_dict() for r in self.reflections],
            "created_at": self.created_at,
            "completed_on": self.completed_on,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Goal":
        """Build a Goal from stored data, enforcing the schema.

        Raises ValidationError (or KeyError/TypeError wrapped as ValidationError)
        when the record is malformed.  Date *ordering* is deliberately not enforced
        here so hand-edited data still loads and gets flagged by the warning engine.
        """
        if not isinstance(data, dict):
            raise ValidationError("record is not an object")
        for key in ("id", "title", "category", "priority", "deadline"):
            if key not in data:
                raise ValidationError(f"missing required field '{key}'")
        try:
            gid = int(data["id"])
        except (TypeError, ValueError):
            raise ValidationError("id must be an integer")
        if gid < 1:
            raise ValidationError("id must be positive")

        created_at = str(data.get("created_at") or datetime.now().isoformat(timespec="seconds"))
        deadline = validate_date(data["deadline"], label="deadline")
        start = validate_date(data.get("start_date") or created_at[:10], label="start_date")

        raw_ms = data.get("milestones") or []
        raw_rf = data.get("reflections") or []
        if not isinstance(raw_ms, list) or not isinstance(raw_rf, list):
            raise ValidationError("milestones/reflections must be lists")
        milestones = []
        for item in raw_ms:
            if not isinstance(item, dict) or "title" not in item:
                raise ValidationError("malformed milestone")
            milestones.append(Milestone(validate_milestone_title(item["title"]), bool(item.get("done", False))))
        reflections = []
        for item in raw_rf:
            if not isinstance(item, dict) or "note" not in item:
                raise ValidationError("malformed reflection")
            reflections.append(Reflection(validate_date(item.get("date") or start, label="reflection date"),
                                          validate_note(item["note"])))
        completed_on = data.get("completed_on") or None
        if completed_on:
            completed_on = validate_date(completed_on, label="completed_on")

        return cls(
            id=gid,
            title=validate_title(data["title"]),
            category=validate_category(data["category"]),
            priority=validate_priority(data["priority"]),
            start_date=start,
            deadline=deadline,
            progress=validate_progress(data.get("progress", 0)),
            description=validate_description(data.get("description", "")),
            milestones=milestones,
            reflections=reflections,
            created_at=created_at,
            completed_on=completed_on,
        )
