"""Multi-format summary export: Markdown, plain-text audit log and CSV reports."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import List

from .csv_io import write_goals_csv
from .logic import GoalManager


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _md(text) -> str:
    return str(text).replace("|", "\\|")


def _bar(pct: float, width: int = 20) -> str:
    filled = int(round(width * max(0.0, min(100.0, pct)) / 100))
    return "#" * filled + "-" * (width - filled)


def export_markdown(manager: GoalManager, path) -> Path:
    s = manager.summary()
    today = manager.today
    lines = [
        "# Personal Goal Review - Executive Summary",
        "",
        f"*As of {s['as_of']} - generated {datetime.now().strftime('%Y-%m-%d %H:%M')}*",
        "",
        "## Key metrics",
        "",
        "| Metric | Value |",
        "|---|---|",
        f"| Total goals | {s['total']} |",
        f"| Completed | {s['completed']} |",
        f"| In progress | {s['in_progress']} |",
        f"| Not started | {s['not_started']} |",
        f"| Overdue | {s['overdue']} |",
        f"| Average completion | {s['avg_completion']}% |",
        f"| Completion rate | {s['completion_rate']}% |",
        f"| Milestones done | {s['milestones_done']} / {s['milestones_total']} |",
        f"| Reflection notes | {s['reflections_total']} |",
        f"| Overall health | **{s['health']}** |",
        "",
        "## By category",
        "",
        "| Category | Goals | Avg completion | Completed | Overdue |",
        "|---|---:|---:|---:|---:|",
    ]
    for cat, d in s["by_category"].items():
        lines.append(f"| {cat} | {d['count']} | {d['avg_completion']}% | {d['completed']} | {d['overdue']} |")
    lines += ["", "## By priority", "", "| Priority | Goals | Avg completion |", "|---|---:|---:|"]
    for pri, d in s["by_priority"].items():
        lines.append(f"| {pri} | {d['count']} | {d['avg_completion']}% |")
    lines += ["", "## Monthly trend", "", "| Month | Started | Completed |", "|---|---:|---:|"]
    for m in s["monthly"]:
        lines.append(f"| {m['month']} | {m['started']} | {m['completed']} |")
    lines += ["", "## Key trends", ""] + [f"- {text}" for text in s["insights"]]

    warns = manager.warnings()
    lines += ["", "## Warnings", ""]
    if warns:
        lines += ["| Level | Goal | Message |", "|---|---|---|"]
        for w in warns:
            ref = f"#{w.goal_id} {w.title}" if w.goal_id else w.title
            lines.append(f"| {w.level} | {_md(ref)} | {w.message} |")
    else:
        lines.append("No warnings - everything looks healthy.")

    lines += ["", "## All goals", "", "| ID | Title | Category | Priority | Deadline | Completion | Status |",
              "|---:|---|---|---|---|---:|---|"]
    for g in manager.sort_goals(manager.goals, "id"):
        lines.append(f"| {g.id} | {_md(g.title)} | {g.category} | {g.priority} | {g.deadline} | "
                     f"{g.completion:.0f}% | {g.status(today)} |")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def export_text_audit(manager: GoalManager, path) -> Path:
    s = manager.summary()
    today = manager.today
    rule = "=" * 78
    lines = [
        rule,
        "PERSONAL GOAL REVIEW - AUDIT LOG",
        f"Generated : {datetime.now().isoformat(timespec='seconds')}",
        f"As of     : {s['as_of']}",
        rule,
        "",
        f"Goals: {s['total']}  Completed: {s['completed']}  In progress: {s['in_progress']}  "
        f"Not started: {s['not_started']}  Overdue: {s['overdue']}",
        f"Average completion: {s['avg_completion']}%   Health: {s['health']}",
        "",
        "WARNINGS",
        "-" * 78,
    ]
    warns = manager.warnings()
    lines += [f"[{w.level:<8}] {('#%d ' % w.goal_id) if w.goal_id else ''}{w.title}: {w.message}"
              for w in warns] or ["(none)"]
    lines += ["", "GOAL RECORDS", "-" * 78]
    for g in manager.sort_goals(manager.goals, "id"):
        lines.append(f"#{g.id:<3} {g.title}")
        lines.append(f"     category={g.category} priority={g.priority} start={g.start_date} "
                     f"deadline={g.deadline} status={g.status(today)}")
        lines.append(f"     completion={g.completion:.1f}% [{_bar(g.completion)}] "
                     f"milestones={g.done_milestones}/{g.total_milestones}")
        for m in g.milestones:
            lines.append(f"       [{'x' if m.done else ' '}] {m.title}")
        for r in g.reflections:
            lines.append(f"       {r.date}  {r.note}")
        lines.append("")
    lines.append(rule)
    lines.append("END OF LOG")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def export_summary_csv(manager: GoalManager, path) -> Path:
    s = manager.summary()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        w = csv.writer(handle)
        w.writerow(["section", "name", "value", "extra"])
        for key in ("total", "completed", "in_progress", "not_started", "overdue", "avg_completion",
                    "completion_rate", "milestones_done", "milestones_total", "reflections_total", "health"):
            w.writerow(["metric", key, s[key], ""])
        for cat, d in s["by_category"].items():
            w.writerow(["category", cat, d["avg_completion"], f"count={d['count']};completed={d['completed']};"
                                                                f"overdue={d['overdue']}"])
        for pri, d in s["by_priority"].items():
            w.writerow(["priority", pri, d["avg_completion"], f"count={d['count']}"])
        for m in s["monthly"]:
            w.writerow(["trend", m["month"], m["completed"], f"started={m['started']}"])
        for warn in manager.warnings():
            w.writerow(["warning", warn.level, warn.message, f"goal={warn.goal_id or ''}"])
    return path


def export_all(manager: GoalManager, out_dir) -> List[Path]:
    """Write all four report files into ``out_dir`` and return their paths."""
    out_dir = Path(out_dir)
    stamp = _stamp()
    return [
        export_markdown(manager, out_dir / f"summary_{stamp}.md"),
        export_text_audit(manager, out_dir / f"audit_log_{stamp}.txt"),
        export_summary_csv(manager, out_dir / f"summary_{stamp}.csv"),
        write_goals_csv(manager.sort_goals(manager.goals, "id"), out_dir / f"goals_report_{stamp}.csv",
                        manager.today),
    ]
