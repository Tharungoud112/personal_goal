"""Bulk import of legacy CSV datasets with format validation and a row-by-row error log."""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from .csv_io import REQUIRED_COLUMNS, map_headers, row_to_goal
from .logic import GoalManager
from .models import Goal
from .validation import ValidationError

MAX_ROWS = 10_000


@dataclass
class ImportResult:
    path: str
    total_rows: int = 0
    imported: int = 0
    skipped: int = 0
    errors: List[Tuple[int, str]] = field(default_factory=list)   # (csv line number, message)
    fatal: Optional[str] = None
    log_path: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.fatal is None


def import_csv(manager: GoalManager, path, log_dir=None) -> ImportResult:
    """Import goals from a CSV file.

    * The header row is checked first (``title`` and ``deadline`` columns are required;
      common aliases such as ``goal`` / ``due_date`` / ``percent`` are understood).
    * Each data row is validated independently - bad rows are skipped and logged with the
      CSV line number and *every* problem found, good rows are still imported.
    * Rows that duplicate an existing goal (same title + deadline) are skipped.
    * A plain-text error log is written when anything was skipped.
    """
    path = Path(path)
    result = ImportResult(path=str(path))

    try:
        handle = open(path, newline="", encoding="utf-8-sig")
    except OSError as exc:
        result.fatal = f"Cannot open file: {exc.strerror or exc}"
        return result

    new_goals: List[Goal] = []
    with handle:
        try:
            reader = csv.reader(handle)
            header = next(reader, None)
            if not header or not any(cell.strip() for cell in header):
                result.fatal = "File is empty or has no header row."
                return result
            mapping = map_headers(header)
            columns = [mapping[h] for h in header]
            missing = [c for c in REQUIRED_COLUMNS if c not in columns]
            if missing:
                result.fatal = (f"Missing required column(s): {', '.join(missing)}. "
                                f"Found: {', '.join(h.strip() for h in header)}")
                return result

            seen = {(g.title.lower(), g.deadline) for g in manager.goals}
            next_id = manager.next_id()
            for row in reader:
                line = reader.line_num
                if not any(cell.strip() for cell in row):
                    continue                                   # blank line
                result.total_rows += 1
                if result.total_rows > MAX_ROWS:
                    result.errors.append((line, f"Row limit of {MAX_ROWS} reached; remaining rows ignored."))
                    result.skipped += 1
                    break
                if len(row) != len(columns):
                    result.errors.append((line, f"Expected {len(columns)} columns but found {len(row)}."))
                    result.skipped += 1
                    continue
                record = dict(zip(columns, row))
                try:
                    goal = row_to_goal(record, next_id, manager.today)
                except ValidationError as exc:
                    result.errors.append((line, str(exc)))
                    result.skipped += 1
                    continue
                key = (goal.title.lower(), goal.deadline)
                if key in seen:
                    result.errors.append((line, f"Duplicate of an existing goal ('{goal.title}', {goal.deadline})."))
                    result.skipped += 1
                    continue
                seen.add(key)
                new_goals.append(goal)
                next_id += 1
        except csv.Error as exc:
            result.fatal = f"Malformed CSV near line {reader.line_num}: {exc}"
            return result

    if new_goals:
        manager.add_many(new_goals)
    result.imported = len(new_goals)

    if result.errors:
        result.log_path = str(_write_log(result, log_dir or path.parent))
    return result


def _write_log(result: ImportResult, directory) -> Path:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    log = directory / f"import_errors_{stamp}.log"
    lines = [
        "Personal Goal Review - CSV import error log",
        f"Source file : {result.path}",
        f"Generated   : {datetime.now().isoformat(timespec='seconds')}",
        f"Rows read   : {result.total_rows}   Imported: {result.imported}   Skipped: {result.skipped}",
        "-" * 70,
    ]
    lines += [f"Line {line}: {message}" for line, message in result.errors]
    log.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return log
