"""Local JSON persistence with schema checks, atomic writes and corruption recovery."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Tuple

from .models import Goal
from .validation import ValidationError

SCHEMA_VERSION = 1


class Storage:
    """Reads/writes the goal list to a JSON file.

    * Missing file            -> a clean template is created.
    * Corrupt / unreadable    -> the bad file is renamed ``*.corrupt-<timestamp>`` and a clean
                                 template is created (nothing is ever silently lost).
    * Individual bad records  -> skipped and reported, the rest still load.
    * Writes are atomic (temp file + ``os.replace``) so a crash cannot truncate the data file.
    """

    def __init__(self, path):
        self.path = Path(path)

    # ------------------------------------------------------------------ load
    def load(self) -> Tuple[List[Goal], List[str]]:
        messages: List[str] = []
        if not self.path.exists():
            self.save([])
            return [], [f"No data file found - created a new empty one at {self.path}."]

        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:                       # raced with a deletion
            self.save([])
            return [], ["Data file disappeared - created a new empty one."]
        except (json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
            return [], [self._quarantine(f"unreadable ({exc.__class__.__name__}: {exc})")]

        if isinstance(raw, list):                       # legacy: bare list of records
            records = raw
        elif isinstance(raw, dict) and isinstance(raw.get("goals"), list):
            records = raw["goals"]
        else:
            return [], [self._quarantine("unexpected structure (no 'goals' list)")]

        goals: List[Goal] = []
        seen = set()
        for index, record in enumerate(records, start=1):
            try:
                goal = Goal.from_dict(record)
            except (ValidationError, KeyError, TypeError, ValueError) as exc:
                messages.append(f"Record #{index} skipped: {exc}")
                continue
            if goal.id in seen:
                messages.append(f"Record #{index} skipped: duplicate id {goal.id}")
                continue
            seen.add(goal.id)
            goals.append(goal)
        return goals, messages

    def _quarantine(self, reason: str) -> str:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}{self.path.suffix}")
        try:
            os.replace(self.path, backup)
            note = f"Data file was {reason}. Backed it up to {backup.name} and started a fresh file."
        except OSError:
            note = f"Data file was {reason}. Could not back it up; starting fresh."
        self.save([])
        return note

    # ------------------------------------------------------------------ save
    def save(self, goals: List[Goal]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "goals": [g.to_dict() for g in goals],
        }
        tmp = self.path.with_name(self.path.name + ".tmp")
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, self.path)
