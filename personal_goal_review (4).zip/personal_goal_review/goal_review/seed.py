"""Realistic sample data: 40 goals with normal entries, boundary values and edge cases.

Dates are generated relative to *today*, so a demo always shows overdue goals,
upcoming deadlines and fresh trends.
"""

from __future__ import annotations

import json
import random
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List

from .csv_io import write_goals_csv
from .models import Goal, Milestone, Reflection
from .validation import DATE_FMT

_TITLES = {
    "Academics": [
        "Finish data structures revision", "Score 8+ CGPA this semester", "Complete DBMS mini project",
        "Prepare for cyber security internals", "Submit research paper draft", "Finish operating systems lab record",
    ],
    "Career": [
        "Build professional portfolio website", "Apply to 15 internships", "Update resume and LinkedIn",
        "Complete full-stack Django course", "Contribute to an open-source project", "Prepare for HR interview rounds",
    ],
    "Health": [
        "Sleep 7 hours every night", "Drink 3 litres of water daily", "Complete 30-day yoga challenge",
        "Annual health check-up", "Cut down screen time to 4 hours",
    ],
    "Fitness": [
        "Run a 5K without stopping", "Gym 4 days a week for 3 months", "Learn to swim 50 metres",
        "Do 25 push-ups in one set",
    ],
    "Finance": [
        "Save Rs 20,000 emergency fund", "Track expenses for 90 days", "Learn index fund investing basics",
        "Pay off credit card balance",
    ],
    "Skills": [
        "Learn Python data analysis basics", "Practise typing at 50 words per minute",
        "Learn the Git and GitHub workflow", "Complete a 20-hour Linux fundamentals course",
    ],
    "Personal": [
        "Read 12 books this year", "Learn basic guitar chords", "Declutter my room and desk",
        "Call family every weekend", "Start a gratitude journal",
    ],
}

_MILESTONES = {
    "Academics": ["Collect syllabus and notes", "Finish first revision", "Solve previous papers",
                  "Clear doubts with faculty", "Take a mock test"],
    "Career": ["Research the options", "Draft the first version", "Get peer feedback",
               "Polish and finalise", "Publish or submit"],
    "Health": ["Set up a tracker", "Complete week one", "Complete week two", "Review habits"],
    "Fitness": ["Get proper shoes or gear", "Finish the beginner plan", "Hit the mid-point target",
                "Do a full trial session"],
    "Finance": ["Open a separate account", "Automate monthly transfer", "Review spending",
                "Reach half the target"],
    "Skills": ["Pick a learning resource", "Finish the first module", "Build a small practice project",
               "Review and note weak spots"],
    "Personal": ["Make a plan", "Set a weekly slot", "Finish the first part", "Finish the second part"],
}

# More than 5 active High-priority goals triggers the workload-limit warning.
MIN_ACTIVE_HIGH_FOR_DEMO = 5

_NOTES = [
    "Good momentum this week, stayed consistent.",
    "Got stuck midway; need to break the task into smaller steps.",
    "Lost a few days to exams, restarting tomorrow.",
    "Feeling confident now that the basics are clear.",
    "Should have started earlier, deadline is closer than I thought.",
    "Asked a friend to hold me accountable.",
    "Finished a big chunk today, very satisfying.",
    "Need to protect time for this in my weekly schedule.",
]


def _iso(d: date) -> str:
    return d.strftime(DATE_FMT)


def generate_sample_goals(today: date | None = None, seed: int = 110) -> List[Goal]:
    """Return 40 goals (ids 1-40): 34 generated + 6 hand-made edge cases."""
    today = today or date.today()
    rng = random.Random(seed)
    goals: List[Goal] = []

    def reflections_for(start: date, count: int) -> List[Reflection]:
        span = max((today - start).days, 0)
        out = []
        for _ in range(count if span else 0):
            when = start + timedelta(days=rng.randint(0, span))
            out.append(Reflection(_iso(when), rng.choice(_NOTES)))
        return sorted(out, key=lambda r: r.date)

    flat = [(cat, title) for cat, titles in _TITLES.items() for title in titles]
    rng.shuffle(flat)
    for cat, title in flat:
        priority = rng.choices(["Low", "Medium", "High"], weights=[3, 4, 3])[0]
        start = today + timedelta(days=rng.randint(-70, 5))
        deadline = start + timedelta(days=rng.randint(35, 150))
        target = rng.choice([0, 10, 25, 40, 55, 70, 85, 100])
        milestones: List[Milestone] = []
        progress = 0
        if rng.random() < 0.65:
            pool = _MILESTONES[cat]
            count = rng.randint(3, len(pool))
            names = rng.sample(pool, count)
            done = round(count * target / 100)
            milestones = [Milestone(n, i < done) for i, n in enumerate(names)]
        else:
            progress = target
        goal = Goal(
            id=len(goals) + 1, title=title, category=cat, priority=priority,
            start_date=_iso(start), deadline=_iso(deadline), progress=progress,
            description=f"{cat} goal: {title.lower()}.", milestones=milestones,
            reflections=reflections_for(start, rng.randint(0, 3)),
            created_at=datetime.combine(start, datetime.min.time()).isoformat(timespec="seconds"),
        )
        if goal.completion >= 100:
            latest = min(deadline + timedelta(days=rng.choice([-10, -3, 0, 0, 4])), today)
            finished = max(start, latest)
            goal.completed_on = _iso(finished)
        goals.append(goal)

    def edge(title, cat, pri, start_off, deadline_off, progress=0, milestones=None, desc="", notes=None):
        start = today + timedelta(days=start_off)
        deadline = today + timedelta(days=deadline_off)
        g = Goal(
            id=len(goals) + 1, title=title, category=cat, priority=pri,
            start_date=_iso(start), deadline=_iso(deadline), progress=progress,
            description=desc, milestones=milestones or [],
            reflections=[Reflection(_iso(today), n) for n in (notes or [])],
            created_at=datetime.combine(start, datetime.min.time()).isoformat(timespec="seconds"),
        )
        if g.completion >= 100:
            g.completed_on = _iso(min(today, deadline))
        goals.append(g)

    # --- boundary values and edge conditions --------------------------------------------------
    edge("Renew passport documents", "Personal", "High", -40, -1, progress=60,
         desc="Overdue by one day - boundary case for overdue detection.")
    edge("Submit scholarship application", "Academics", "High", -20, 0, progress=0,
         desc="Due today with zero progress - boundary case for deadline warnings.")
    edge("Finish capstone abstract and keyword list before the department review panel day",
         "Academics", "Medium", -5, 25, progress=100,
         desc="Title is exactly 80 characters - boundary case for length validation.")
    edge('Plan family trip to Goa, Kerala & "Hampi"', "Personal", "Low", -2, 60, progress=0,
         desc="Commas, quotes and ampersands - checks CSV/JSON round-tripping.",
         notes=["Compare train vs flight, budget: 25,000 rupees."])
    edge("Learn Rust for systems programming", "Career", "Low", -45, 1500, progress=0,
         desc="Deadline over 3 years away - unusual value that triggers an anomaly note.")
    edge("Master the 8-step incident response playbook", "Career", "High", -30, 12,
         milestones=[Milestone(f"Step {i}", True) for i in range(1, 9)],
         desc="Eight milestones, all done - fully complete by milestones.",
         notes=["Walked through every step with the lab team."])

    # make sure the workload-limit warning can be demonstrated
    active_high = [g for g in goals if g.priority == "High" and g.completion < 100]
    for g in goals:
        if len(active_high) > MIN_ACTIVE_HIGH_FOR_DEMO:
            break
        if g.priority != "High" and g.completion < 100:
            g.priority = "High"
            active_high.append(g)
    return goals


def write_sample_files(directory, today: date | None = None) -> List[Path]:
    """Write data/sample_goals.json and data/sample_goals.csv."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    today = today or date.today()
    goals = generate_sample_goals(today)
    json_path = directory / "sample_goals.json"
    json_path.write_text(json.dumps({"schema_version": 1, "goals": [g.to_dict() for g in goals]},
                                    indent=2, ensure_ascii=False), encoding="utf-8")
    csv_path = write_goals_csv(goals, directory / "sample_goals.csv", today)
    return [json_path, csv_path]


LEGACY_CSV = '''Goal,Category,Priority,Start Date,Due Date,Percent,Milestones,Notes
Finish network security lab,Academics,High,2026-10-01,2026-12-20,40,[x] Setup VM;[x] Nmap scans;[ ] Write report;[ ] Viva prep,2026-10-12: Scans took longer than planned
Practice aptitude tests,Career,Medium,01/11/2026,31/12/2026,25,,Doing two papers a week
Save for laptop upgrade,Finance,low,2026-09-01,2027-03-31,55,,
Walk 10000 steps daily,Health,H,2026-11-01,2026-12-31,70,,
Learn Flask basics,Skills,Medium,2026-11-10,2026-12-15,0,Install Flask;Build hello app;Add templates,
,Career,High,2026-11-01,2026-12-01,10,,Missing title - should be rejected
Write blog post,Career,Urgent,2026-11-01,2026-12-01,10,,Bad priority - should be rejected
Read operating systems book,Academics,Medium,2026-11-01,2026-13-45,10,,Impossible date - should be rejected
Fix bike,Personal,Low,2026-12-01,2026-11-01,0,,Deadline before start - should be rejected
Meditate daily,Health,Medium,2026-11-01,2026-12-31,150,,Progress above 100 - should be rejected
Run 5K,Fitness,High,2026-11-01,2026-12-31,abc,,Non-numeric progress - should be rejected
Finish network security lab,Academics,High,2026-10-01,2026-12-20,40,,Duplicate of row 1 - should be skipped
Clean desk,Personal,Low,2026-11-20,2026-11-30
Learn guitar chords,Personal,Medium,2026-11-01,2026-12-31,35,,Good row after the bad ones
'''


def write_legacy_sample(directory) -> Path:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "legacy_import_sample.csv"
    path.write_text(LEGACY_CSV, encoding="utf-8")
    return path
