"""Defensive input validation for Personal Goal Review.

Every validator takes raw user input (usually a string), sanitises it and either
returns a clean, normalised value or raises :class:`ValidationError` with a
human-friendly message.  The same validators are shared by the terminal UI,
the Tkinter GUI, the CSV importer and the JSON loader, so a rule is defined
exactly once.
"""

from __future__ import annotations

import re
from datetime import date, datetime

DATE_FMT = "%Y-%m-%d"
PRIORITIES = ("Low", "Medium", "High")
STATUSES = ("Not Started", "In Progress", "Completed", "Overdue")

TITLE_MIN, TITLE_MAX = 3, 80
CATEGORY_MAX = 30
DESCRIPTION_MAX = 300
MILESTONE_MIN, MILESTONE_MAX = 2, 60
NOTE_MAX = 500
KEYWORD_MAX = 60
MAX_MILESTONES_PER_GOAL = 20
MIN_YEAR, MAX_YEAR = 2000, 2100


class ValidationError(ValueError):
    """Raised when a user-supplied value does not satisfy domain constraints."""


_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
_CATEGORY_RE = re.compile(r"^[A-Za-z][A-Za-z0-9 &/\-]{1,%d}$" % (CATEGORY_MAX - 1))
_CHECKBOX_PREFIX = re.compile(r"^\[[ xX]\]\s*")
_DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d")

_PRIORITY_ALIASES = {
    "l": "Low", "low": "Low", "1": "Low",
    "m": "Medium", "med": "Medium", "medium": "Medium", "2": "Medium",
    "h": "High", "high": "High", "3": "High",
}
_STATUS_ALIASES = {
    "ns": "Not Started", "not started": "Not Started", "not_started": "Not Started",
    "notstarted": "Not Started", "new": "Not Started",
    "ip": "In Progress", "in progress": "In Progress", "in_progress": "In Progress",
    "inprogress": "In Progress", "active": "In Progress",
    "c": "Completed", "done": "Completed", "complete": "Completed", "completed": "Completed",
    "o": "Overdue", "overdue": "Overdue", "late": "Overdue",
}


def sanitize_text(text) -> str:
    """Strip control characters, collapse whitespace and trim."""
    if text is None:
        return ""
    text = _CONTROL_CHARS.sub("", str(text))
    return re.sub(r"\s+", " ", text).strip()


def _check_length(value: str, label: str, lo: int, hi: int) -> None:
    if len(value) < lo:
        raise ValidationError(f"{label} must be at least {lo} characters (got {len(value)}).")
    if len(value) > hi:
        raise ValidationError(f"{label} must be at most {hi} characters (got {len(value)}).")


def validate_title(text) -> str:
    value = sanitize_text(text)
    _check_length(value, "Title", TITLE_MIN, TITLE_MAX)
    if not re.search(r"[A-Za-z0-9\u00C0-\uFFFF]", value):
        raise ValidationError("Title must contain at least one letter or digit.")
    return value


def validate_category(text) -> str:
    value = sanitize_text(text)
    if not value:
        raise ValidationError("Category cannot be blank.")
    if not _CATEGORY_RE.match(value):
        raise ValidationError(
            f"Category must start with a letter, be 2-{CATEGORY_MAX} characters and use only "
            "letters, digits, spaces, '&', '/' or '-'."
        )
    return value[0].upper() + value[1:]


def validate_priority(text) -> str:
    value = sanitize_text(text).lower()
    if value not in _PRIORITY_ALIASES:
        raise ValidationError("Priority must be Low, Medium or High (or L / M / H, or 1 / 2 / 3).")
    return _PRIORITY_ALIASES[value]


def validate_priority_filter(text) -> str:
    """Like :func:`validate_priority` but a blank value means 'any'."""
    return "" if not sanitize_text(text) else validate_priority(text)


def validate_status_filter(text) -> str:
    value = sanitize_text(text).lower()
    if not value:
        return ""
    if value not in _STATUS_ALIASES:
        raise ValidationError("Status must be Not Started, In Progress, Completed or Overdue.")
    return _STATUS_ALIASES[value]


def validate_description(text) -> str:
    value = sanitize_text(text)
    if len(value) > DESCRIPTION_MAX:
        raise ValidationError(f"Description must be at most {DESCRIPTION_MAX} characters (got {len(value)}).")
    return value


def validate_date(text, allow_blank: bool = False, label: str = "Date") -> str:
    """Parse a date typed as YYYY-MM-DD, DD-MM-YYYY, DD/MM/YYYY or YYYY/MM/DD -> ISO string."""
    if isinstance(text, (date, datetime)):
        text = text.strftime(DATE_FMT)
    value = sanitize_text(text)
    if not value:
        if allow_blank:
            return ""
        raise ValidationError(f"{label} cannot be blank. Use YYYY-MM-DD (e.g. 2026-12-31).")
    parsed = None
    for fmt in _DATE_FORMATS:
        try:
            parsed = datetime.strptime(value, fmt).date()
            break
        except ValueError:
            continue
    if parsed is None:
        raise ValidationError(f"{label} '{value}' is not a valid date. Use YYYY-MM-DD (e.g. 2026-12-31).")
    if not (MIN_YEAR <= parsed.year <= MAX_YEAR):
        raise ValidationError(f"{label} year must be between {MIN_YEAR} and {MAX_YEAR}.")
    return parsed.strftime(DATE_FMT)


def validate_date_order(start_iso: str, deadline_iso: str) -> None:
    if deadline_iso < start_iso:  # ISO strings sort chronologically
        raise ValidationError(f"Deadline ({deadline_iso}) cannot be earlier than the start date ({start_iso}).")


def parse_iso(value: str) -> date:
    return datetime.strptime(value, DATE_FMT).date()


def validate_progress(value) -> int:
    """Whole number 0-100 (a trailing % sign is accepted)."""
    msg = "Progress must be a whole number between 0 and 100."
    if isinstance(value, bool):
        raise ValidationError(msg)
    if isinstance(value, (int, float)):
        if isinstance(value, float) and not value.is_integer():
            raise ValidationError(msg)
        number = int(value)
    else:
        text = sanitize_text(value).rstrip("%").strip()
        if not re.fullmatch(r"\d{1,3}(\.0+)?", text):
            raise ValidationError(msg)
        number = int(float(text))
    if not 0 <= number <= 100:
        raise ValidationError(msg)
    return number


def validate_milestone_title(text) -> str:
    value = _CHECKBOX_PREFIX.sub("", sanitize_text(text)).replace(";", ",")
    _check_length(value, "Milestone", MILESTONE_MIN, MILESTONE_MAX)
    return value


def validate_note(text) -> str:
    value = sanitize_text(text).replace("|", "/")
    _check_length(value, "Reflection note", 1, NOTE_MAX)
    return value


def validate_keyword(text) -> str:
    value = sanitize_text(text)
    if len(value) > KEYWORD_MAX:
        raise ValidationError(f"Keyword must be at most {KEYWORD_MAX} characters.")
    return value


def validate_int_range(text, lo: int, hi: int, label: str = "Value") -> int:
    value = sanitize_text(text)
    if not re.fullmatch(r"-?\d+", value):
        raise ValidationError(f"{label} must be a whole number between {lo} and {hi}.")
    number = int(value)
    if not lo <= number <= hi:
        raise ValidationError(f"{label} must be between {lo} and {hi}.")
    return number
