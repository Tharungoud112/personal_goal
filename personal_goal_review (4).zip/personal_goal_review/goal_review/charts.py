"""Charts: dependency-free text charts, plus an optional Matplotlib PNG export."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Tuple

from .logic import GoalManager


def text_bars(items: Iterable[Tuple[str, float]], width: int = 30, max_value: float = 100.0,
              suffix: str = "%", label_width: int = 14) -> List[str]:
    """Return lines like ``Career      ███████████░░░░░░░░░ 55%``."""
    lines = []
    for label, value in items:
        filled = int(round(width * max(0.0, min(value, max_value)) / max_value)) if max_value else 0
        bar = "█" * filled + "░" * (width - filled)
        lines.append(f"{label[:label_width]:<{label_width}} {bar} {value:.0f}{suffix}")
    return lines


def matplotlib_available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def save_summary_chart(manager: GoalManager, path) -> Path:
    """Save a 3-panel PNG (category completion, status mix, monthly trend).

    Raises ImportError if Matplotlib is not installed (it is optional).
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    s = manager.summary()
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    fig.suptitle(f"Personal Goal Review - {s['as_of']}  |  {s['total']} goals, "
                 f"avg {s['avg_completion']}% complete, {s['health']}", fontsize=12, fontweight="bold")

    cats = list(s["by_category"].items())
    names = [c for c, _ in cats]
    values = [d["avg_completion"] for _, d in cats]
    axes[0].barh(names, values, color="#2e86de")
    axes[0].set_xlim(0, 100)
    axes[0].set_title("Average completion by category (%)")
    axes[0].invert_yaxis()
    for i, v in enumerate(values):
        axes[0].text(v + 1, i, f"{v:.0f}%", va="center", fontsize=8)

    status_colors = {"Not Started": "#95a5a6", "In Progress": "#f39c12",
                     "Completed": "#27ae60", "Overdue": "#e74c3c"}
    labels = list(s["by_status"].keys())
    counts = [s["by_status"][k] for k in labels]
    axes[1].bar(labels, counts, color=[status_colors[k] for k in labels])
    axes[1].set_title("Goals by status")
    axes[1].tick_params(axis="x", labelrotation=20)
    for i, v in enumerate(counts):
        axes[1].text(i, v + 0.1, str(v), ha="center", fontsize=9)

    months = [m["month"] for m in s["monthly"]]
    x = range(len(months))
    axes[2].bar([i - 0.2 for i in x], [m["started"] for m in s["monthly"]], width=0.4,
                label="Started", color="#2e86de")
    axes[2].bar([i + 0.2 for i in x], [m["completed"] for m in s["monthly"]], width=0.4,
                label="Completed", color="#27ae60")
    axes[2].set_xticks(list(x))
    axes[2].set_xticklabels(months, rotation=30, fontsize=8)
    axes[2].set_title("Monthly trend")
    axes[2].legend()

    fig.tight_layout(rect=(0, 0, 1, 0.94))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path
