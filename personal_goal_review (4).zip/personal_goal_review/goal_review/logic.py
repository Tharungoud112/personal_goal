"""Core business logic: goal tracking, milestones, completion %, reflections,
search/filtering, executive summary and threshold warnings."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional

from .models import (
    Goal,
    Milestone,
    Reflection,
    STATUS_COMPLETED,
    STATUS_IN_PROGRESS,
    STATUS_NOT_STARTED,
    STATUS_OVERDUE,
)
from .storage import Storage
from .validation import (
    DATE_FMT,
    MAX_MILESTONES_PER_GOAL,
    PRIORITIES,
    ValidationError,
    parse_iso,
    sanitize_text,
    validate_category,
    validate_date,
    validate_date_order,
    validate_description,
    validate_milestone_title,
    validate_note,
    validate_priority,
    validate_progress,
    validate_title,
)

LEVEL_CRITICAL, LEVEL_WARNING, LEVEL_INFO = "CRITICAL", "WARNING", "INFO"
_LEVEL_ORDER = {LEVEL_CRITICAL: 0, LEVEL_WARNING: 1, LEVEL_INFO: 2}
_PRIORITY_ORDER = {"High": 0, "Medium": 1, "Low": 2}

SORT_KEYS = ("deadline", "completion", "title", "priority", "id")


class GoalNotFound(KeyError):
    """Raised when a goal id does not exist."""

    def __str__(self) -> str:                      # KeyError normally repr()s its message
        return str(self.args[0]) if self.args else "Goal not found"


class GoalManagerError(ValueError):
    """Raised for business-rule violations (as opposed to bad input format)."""


@dataclass
class Warn:
    level: str
    kind: str
    goal_id: Optional[int]
    title: str
    message: str


class GoalManager:
    DUE_SOON_DAYS = 7
    STALE_DAYS = 30
    FAR_DEADLINE_DAYS = 365 * 3
    MAX_ACTIVE_HIGH = 5

    def __init__(self, storage: Storage, today: Optional[date] = None):
        self.storage = storage
        self._today = today
        self.goals: List[Goal] = []
        self.load_messages: List[str] = []
        self.reload()

    # ------------------------------------------------------------- plumbing
    @property
    def today(self) -> date:
        return self._today or date.today()

    def reload(self) -> None:
        self.goals, self.load_messages = self.storage.load()

    def save(self) -> None:
        self.storage.save(self.goals)

    def next_id(self) -> int:
        return max((g.id for g in self.goals), default=0) + 1

    def get(self, goal_id: int) -> Goal:
        for goal in self.goals:
            if goal.id == goal_id:
                return goal
        raise GoalNotFound(f"No goal with ID {goal_id}.")

    def categories(self) -> List[str]:
        return sorted({g.category for g in self.goals})

    def _sync_completion(self, goal: Goal) -> None:
        if goal.completion >= 100:
            if not goal.completed_on:
                goal.completed_on = self.today.strftime(DATE_FMT)
        else:
            goal.completed_on = None

    # ----------------------------------------------------------------- CRUD
    def add_goal(self, title, category, priority, start_date, deadline, description="",
                 progress=0, milestones=None) -> Goal:
        title = validate_title(title)
        category = validate_category(category)
        priority = validate_priority(priority)
        start_date = validate_date(start_date, label="Start date")
        deadline = validate_date(deadline, label="Deadline")
        validate_date_order(start_date, deadline)
        description = validate_description(description)
        progress = validate_progress(progress)
        ms = [Milestone(validate_milestone_title(m)) for m in (milestones or [])]
        if len(ms) > MAX_MILESTONES_PER_GOAL:
            raise GoalManagerError(f"A goal can have at most {MAX_MILESTONES_PER_GOAL} milestones.")

        goal = Goal(
            id=self.next_id(), title=title, category=category, priority=priority,
            start_date=start_date, deadline=deadline, progress=progress,
            description=description, milestones=ms,
            created_at=datetime.now().isoformat(timespec="seconds"),
        )
        self._sync_completion(goal)
        self.goals.append(goal)
        self.save()
        return goal

    def add_many(self, goals: List[Goal]) -> None:
        """Append pre-validated goals (used by the importer / sample loader) with one save."""
        for goal in goals:
            goal.id = self.next_id()
            self._sync_completion(goal)
            self.goals.append(goal)
        self.save()

    def update_goal(self, goal_id: int, **changes) -> Goal:
        goal = self.get(goal_id)
        allowed = {"title", "category", "priority", "start_date", "deadline", "description", "progress"}
        unknown = set(changes) - allowed
        if unknown:
            raise GoalManagerError(f"Cannot edit field(s): {', '.join(sorted(unknown))}")
        clean = {}
        if "title" in changes:
            clean["title"] = validate_title(changes["title"])
        if "category" in changes:
            clean["category"] = validate_category(changes["category"])
        if "priority" in changes:
            clean["priority"] = validate_priority(changes["priority"])
        if "start_date" in changes:
            clean["start_date"] = validate_date(changes["start_date"], label="Start date")
        if "deadline" in changes:
            clean["deadline"] = validate_date(changes["deadline"], label="Deadline")
        if "description" in changes:
            clean["description"] = validate_description(changes["description"])
        if "progress" in changes:
            if goal.milestones:
                raise GoalManagerError("Progress is calculated from milestones for this goal. "
                                       "Tick milestones instead.")
            clean["progress"] = validate_progress(changes["progress"])
        validate_date_order(clean.get("start_date", goal.start_date), clean.get("deadline", goal.deadline))
        for key, value in clean.items():           # apply only after everything validated
            setattr(goal, key, value)
        self._sync_completion(goal)
        self.save()
        return goal

    def delete_goal(self, goal_id: int) -> Goal:
        goal = self.get(goal_id)
        self.goals.remove(goal)
        self.save()
        return goal

    # ------------------------------------------------- progress & milestones
    def set_progress(self, goal_id: int, value) -> Goal:
        return self.update_goal(goal_id, progress=value)

    def add_milestone(self, goal_id: int, title) -> Goal:
        goal = self.get(goal_id)
        title = validate_milestone_title(title)
        if len(goal.milestones) >= MAX_MILESTONES_PER_GOAL:
            raise GoalManagerError(f"A goal can have at most {MAX_MILESTONES_PER_GOAL} milestones.")
        if any(m.title.lower() == title.lower() for m in goal.milestones):
            raise GoalManagerError(f"Milestone '{title}' already exists for this goal.")
        goal.milestones.append(Milestone(title))
        self._sync_completion(goal)
        self.save()
        return goal

    def toggle_milestone(self, goal_id: int, index: int) -> Goal:
        goal = self.get(goal_id)
        if not 0 <= index < len(goal.milestones):
            raise GoalManagerError(f"Milestone number must be between 1 and {len(goal.milestones)}.")
        goal.milestones[index].done = not goal.milestones[index].done
        self._sync_completion(goal)
        self.save()
        return goal

    def remove_milestone(self, goal_id: int, index: int) -> Goal:
        goal = self.get(goal_id)
        if not 0 <= index < len(goal.milestones):
            raise GoalManagerError(f"Milestone number must be between 1 and {len(goal.milestones)}.")
        del goal.milestones[index]
        self._sync_completion(goal)
        self.save()
        return goal

    def complete_goal(self, goal_id: int) -> Goal:
        goal = self.get(goal_id)
        for milestone in goal.milestones:
            milestone.done = True
        goal.progress = 100
        self._sync_completion(goal)
        self.save()
        return goal

    # ----------------------------------------------------------- reflections
    def add_reflection(self, goal_id: int, note, on: Optional[str] = None) -> Goal:
        goal = self.get(goal_id)
        note = validate_note(note)
        when = validate_date(on, label="Date") if on else self.today.strftime(DATE_FMT)
        goal.reflections.append(Reflection(when, note))
        self.save()
        return goal

    # ---------------------------------------------------------------- search
    def search(self, keyword: str = "", category: str = "", status: str = "",
               priority: str = "", sort_by: str = "deadline") -> List[Goal]:
        """AND-combine a keyword search (every word must match somewhere in the goal's
        title, category, description, milestones or reflections) with exact filters."""
        words = sanitize_text(keyword).lower().split()
        category = sanitize_text(category).lower()
        status = sanitize_text(status).lower()
        priority = sanitize_text(priority).lower()
        today = self.today
        results = []
        for goal in self.goals:
            if category and goal.category.lower() != category:
                continue
            if priority and goal.priority.lower() != priority:
                continue
            if status and goal.status(today).lower() != status:
                continue
            if words:
                haystack = " ".join(
                    [goal.title, goal.category, goal.description]
                    + [m.title for m in goal.milestones]
                    + [r.note for r in goal.reflections]
                ).lower()
                if not all(word in haystack for word in words):
                    continue
            results.append(goal)
        return self.sort_goals(results, sort_by)

    def sort_goals(self, goals: List[Goal], sort_by: str = "deadline") -> List[Goal]:
        if sort_by == "completion":
            return sorted(goals, key=lambda g: (-g.completion, g.id))
        if sort_by == "title":
            return sorted(goals, key=lambda g: (g.title.lower(), g.id))
        if sort_by == "priority":
            return sorted(goals, key=lambda g: (_PRIORITY_ORDER[g.priority], g.deadline, g.id))
        if sort_by == "id":
            return sorted(goals, key=lambda g: g.id)
        return sorted(goals, key=lambda g: (g.deadline, g.id))

    # --------------------------------------------------------------- summary
    def summary(self) -> Dict:
        """Executive summary: totals, averages, status indicators and trends."""
        today = self.today
        goals = self.goals
        n = len(goals)
        statuses = Counter(g.status(today) for g in goals)
        completed = statuses[STATUS_COMPLETED]
        overdue = statuses[STATUS_OVERDUE]
        active = n - completed

        def mean(items):
            items = list(items)
            return round(sum(items) / len(items), 1) if items else 0.0

        groups = defaultdict(list)
        for goal in goals:
            groups[goal.category].append(goal)
        by_category = {
            cat: {
                "count": len(items),
                "avg_completion": mean(g.completion for g in items),
                "completed": sum(1 for g in items if g.status(today) == STATUS_COMPLETED),
                "overdue": sum(1 for g in items if g.status(today) == STATUS_OVERDUE),
            }
            for cat, items in sorted(groups.items())
        }
        by_priority = {}
        for pri in PRIORITIES:
            items = [g for g in goals if g.priority == pri]
            by_priority[pri] = {"count": len(items), "avg_completion": mean(g.completion for g in items)}

        due_soon = [g for g in goals
                    if g.status(today) != STATUS_COMPLETED and 0 <= g.days_left(today) <= self.DUE_SOON_DAYS]
        horizon = today - timedelta(days=30)
        completed_30d = [g for g in goals if g.completed_on and parse_iso(g.completed_on) >= horizon]
        reflections_30d = sum(1 for g in goals for r in g.reflections if parse_iso(r.date) >= horizon)

        ratio = (overdue / active) if active else 0.0
        if n == 0:
            health = "No data"
        elif active == 0:
            health = "All goals completed"
        elif ratio >= 0.4:
            health = "Critical"
        elif ratio >= 0.2:
            health = "At risk"
        else:
            health = "On track"

        monthly = self._monthly_trend(6)
        insights = []
        if n:
            insights.append(f"Completion rate is {round(100 * completed / n, 1)}% ({completed} of {n} goals).")
        if len(by_category) >= 2:
            ranked = sorted(by_category.items(), key=lambda kv: (-kv[1]["avg_completion"], kv[0]))
            best, worst = ranked[0], ranked[-1]
            insights.append(f"Strongest category: {best[0]} ({best[1]['avg_completion']}% avg).")
            insights.append(f"Needs most attention: {worst[0]} ({worst[1]['avg_completion']}% avg).")
        if n:
            busiest = max(by_category.items(), key=lambda kv: (kv[1]["count"], kv[0]))
            insights.append(f"Most goals sit in {busiest[0]} ({busiest[1]['count']}).")
        insights.append(f"{len(completed_30d)} goal(s) completed in the last 30 days.")
        insights.append(f"{len(due_soon)} goal(s) due within {self.DUE_SOON_DAYS} days.")
        insights.append(f"{reflections_30d} reflection note(s) written in the last 30 days.")
        if by_priority["High"]["count"]:
            insights.append(f"High-priority goals average {by_priority['High']['avg_completion']}% complete.")

        return {
            "as_of": today.strftime(DATE_FMT),
            "total": n,
            "completed": completed,
            "in_progress": statuses[STATUS_IN_PROGRESS],
            "not_started": statuses[STATUS_NOT_STARTED],
            "overdue": overdue,
            "avg_completion": mean(g.completion for g in goals),
            "completion_rate": round(100 * completed / n, 1) if n else 0.0,
            "milestones_total": sum(g.total_milestones for g in goals),
            "milestones_done": sum(g.done_milestones for g in goals),
            "reflections_total": sum(len(g.reflections) for g in goals),
            "reflections_30d": reflections_30d,
            "completed_30d": len(completed_30d),
            "due_soon": [g.id for g in due_soon],
            "by_category": by_category,
            "by_priority": by_priority,
            "by_status": {s: statuses[s] for s in
                          (STATUS_NOT_STARTED, STATUS_IN_PROGRESS, STATUS_COMPLETED, STATUS_OVERDUE)},
            "monthly": monthly,
            "health": health,
            "insights": insights,
        }

    def _monthly_trend(self, months: int) -> List[Dict]:
        today = self.today
        keys = []
        year, month = today.year, today.month
        for _ in range(months):
            keys.append(f"{year:04d}-{month:02d}")
            month -= 1
            if month == 0:
                year, month = year - 1, 12
        keys.reverse()
        created = Counter(g.start_date[:7] for g in self.goals)
        done = Counter(g.completed_on[:7] for g in self.goals if g.completed_on)
        return [{"month": k, "started": created.get(k, 0), "completed": done.get(k, 0)} for k in keys]

    # -------------------------------------------------------------- warnings
    def warnings(self) -> List[Warn]:
        """Threshold indicators: overdue, due soon, anomalies and limit breaches."""
        today = self.today
        out: List[Warn] = []

        titles = defaultdict(list)
        for goal in self.goals:
            titles[goal.title.lower()].append(goal.id)

        active_high = 0
        for g in self.goals:
            status = g.status(today)
            left = g.days_left(today)
            pct = f"{g.completion:.0f}%"
            if status == STATUS_COMPLETED:
                if g.completed_on and g.completed_on > g.deadline:
                    out.append(Warn(LEVEL_INFO, "late-completion", g.id, g.title,
                                    f"Completed {g.completed_on}, after its deadline of {g.deadline}."))
            else:
                if g.priority == "High":
                    active_high += 1
                if status == STATUS_OVERDUE:
                    level = LEVEL_CRITICAL if g.priority == "High" else LEVEL_WARNING
                    out.append(Warn(level, "overdue", g.id, g.title,
                                    f"Overdue by {-left} day(s) at {pct} complete ({g.priority} priority)."))
                elif left <= self.DUE_SOON_DAYS and g.completion < 50:
                    level = LEVEL_CRITICAL if (left <= 2 and g.priority == "High") else LEVEL_WARNING
                    when = "today" if left == 0 else f"in {left} day(s)"
                    out.append(Warn(level, "due-soon", g.id, g.title,
                                    f"Due {when} but only {pct} complete."))
                start = parse_iso(g.start_date)
                if (g.completion == 0 and status != STATUS_OVERDUE
                        and (today - start).days >= self.STALE_DAYS):
                    out.append(Warn(LEVEL_INFO, "stale", g.id, g.title,
                                    f"No progress recorded {(today - start).days} days after the start date."))
            if g.deadline < g.start_date:
                out.append(Warn(LEVEL_WARNING, "anomaly", g.id, g.title,
                                f"Anomaly: deadline {g.deadline} is before start date {g.start_date}."))
            if left > self.FAR_DEADLINE_DAYS and status != STATUS_COMPLETED:
                out.append(Warn(LEVEL_INFO, "anomaly", g.id, g.title,
                                f"Unusual deadline {g.deadline} is more than 3 years away."))
            if len(titles[g.title.lower()]) > 1 and g.id == min(titles[g.title.lower()]):
                ids = ", ".join(f"#{i}" for i in titles[g.title.lower()])
                out.append(Warn(LEVEL_INFO, "duplicate", g.id, g.title, f"Duplicate title across goals {ids}."))

        if active_high > self.MAX_ACTIVE_HIGH:
            out.append(Warn(LEVEL_WARNING, "limit", None, "Workload limit",
                            f"{active_high} active High-priority goals exceed the recommended maximum "
                            f"of {self.MAX_ACTIVE_HIGH}."))
        out.sort(key=lambda w: (_LEVEL_ORDER[w.level], w.goal_id if w.goal_id is not None else 10**9))
        return out
