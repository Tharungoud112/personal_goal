"""Personal Goal Review - goal, milestone, progress and reflection tracker."""

__version__ = "1.0.0"
