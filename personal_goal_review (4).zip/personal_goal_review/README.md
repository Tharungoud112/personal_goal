# Personal Goal Review

**Hackathon Project #110 - LocalImpact Challenge - Digital Tools & Productivity**

A complete, zero-dependency Python application to track **goals, milestones, completion percentage and
reflection notes**, with strict input validation, reliable local JSON persistence, searchable records,
executive summaries, warnings, exports, bulk CSV import - and **two interfaces**: a menu-driven
terminal app and a Tkinter desktop GUI.

## Quick start

```bash
python main.py              # terminal interface (default)
python main.py --gui        # Tkinter graphical interface
python main.py --seed       # load the 40-goal sample dataset first (if no data yet)
python -m unittest discover -s tests -v    # run the 23 unit tests
```

* Requires **Python 3.10+** only. No `pip install` needed.
* Optional: `pip install matplotlib` to save a PNG chart (the on-screen charts work without it).
* Tkinter ships with Python on Windows/macOS. On Debian/Ubuntu: `sudo apt install python3-tk`.
* Your data is stored in `data/goals.json` and survives restarts.

## Requirement checklist (from the problem brief)

| Brief requirement | Where it lives |
|---|---|
| **Interactive terminal interface** - menu-driven, ANSI colours, branded welcome screen | `goal_review/cli.py` |
| **Defensive input validation** - sanitising, range checks, loops until valid | `goal_review/validation.py` (shared by CLI, GUI, importer, loader) |
| **Core logic engine** - goals, milestones, completion %, reflection notes | `goal_review/logic.py`, `goal_review/models.py` |
| **Local persistence** - JSON, schema checks, survives restarts | `goal_review/storage.py` |
| **Record query & search** - keyword + category/status/priority filters, sorting | `GoalManager.search`, menu 7, GUI filter bar |
| **Executive summary** - totals, averages, status indicators, trends | `GoalManager.summary`, menu 8, GUI Dashboard |
| *Stretch* **Multi-format export** - Markdown, plain-text audit log, CSV | `goal_review/reports.py`, menu 11 |
| *Stretch* **Threshold warning indicators** - overdue, due soon, anomalies, limit breaches | `GoalManager.warnings`, menu 9, GUI Warnings tab |
| *Stretch* **GUI** - Tkinter | `goal_review/gui.py` (`--gui` or menu `G`) |
| *Stretch* **Bulk CSV import** with row-by-row error log | `goal_review/importer.py`, menu 12 |
| Sample data - 30-50 entries as CSV **and** JSON, incl. boundary/edge cases | `data/sample_goals.json`, `data/sample_goals.csv` (40 goals) |
| Matplotlib plotting where applicable | `goal_review/charts.py` (text charts built in, PNG via Matplotlib) |

### How the model works
* A goal has a title, category, priority (Low/Medium/High), start date, deadline, description,
  **milestones**, **reflection notes** and a manual progress %.
* **Completion %** = milestones done / total milestones. A goal with no milestones uses its manual progress.
* **Status** is computed: *Not Started*, *In Progress*, *Completed* or *Overdue* (deadline passed, not complete).
* Dates accept `YYYY-MM-DD`, `DD/MM/YYYY` or `DD-MM-YYYY`. Type `:q` at any terminal prompt to cancel.

### Warning rules
`CRITICAL` / `WARNING` / `INFO` flags for: overdue goals (High priority = critical), goals due within 7 days
and under 50% done, deadline before start date, deadlines more than 3 years away, goals with no progress 30+ days
after starting, duplicate titles, goals completed late, and more than 5 active High-priority goals.

### Resilient by design
* Missing data file -> clean template created. Corrupt/unreadable JSON -> backed up as
  `goals.corrupt-<timestamp>.json` and a fresh file started. Bad individual records are skipped and reported.
* Writes are atomic (temp file + replace), so a crash can't truncate your data.
* Blank / non-numeric / out-of-range input never crashes the app; it re-prompts with a clear message.

## Suggested 5-minute demo
1. `python main.py` - show the branded welcome screen and menu.
2. **1** Add a goal - type `ab` as the title, `urgent` as priority, `2020-13-45` as deadline to show validation
   catching each one, then enter valid values and a couple of milestones.
3. **5** tick a milestone and watch the completion % change; **6** add a reflection note.
4. **13** load the sample dataset, then **7** search (`django`, category `career`, status `overdue`...).
5. **8** summary, **9** warnings, **10** charts.
6. **0** exit, relaunch, **2** list goals - everything persisted.
7. **11** export reports into `exports/`; **12** import `data/legacy_import_sample.csv` to show the row-by-row error log.
8. `python main.py --gui` - Goals, Dashboard and Warnings tabs.

## Project layout
```
personal_goal_review/
  main.py                  launcher (CLI by default, --gui for Tkinter)
  goal_review/
    validation.py          every input rule, defined once
    models.py              Goal / Milestone / Reflection dataclasses
    storage.py             JSON persistence, corruption recovery, atomic writes
    logic.py               GoalManager: CRUD, milestones, search, summary, warnings
    csv_io.py              CSV (de)serialisation helpers
    importer.py            bulk CSV import + error log
    reports.py             Markdown / text audit / CSV exports
    charts.py              text bar charts + optional Matplotlib PNG
    seed.py                40-goal sample dataset generator
    cli.py                 terminal interface
    gui.py                 Tkinter interface
  data/                    sample_goals.json / .csv, legacy_import_sample.csv (goals.json is created on first run)
  exports/                 generated reports land here
  tests/test_core.py       unit tests
```

## CSV format (import & export)
`id,title,category,priority,start_date,deadline,progress,completion,status,milestones,reflections,description,created_at,completed_on`

Only `title` and `deadline` are required for import. Milestones: `[x] Done item;[ ] Open item`.
Reflections: `2026-11-05: note one | 2026-11-09: note two`. Aliases such as `goal`, `due_date`, `percent`, `notes` are understood.
